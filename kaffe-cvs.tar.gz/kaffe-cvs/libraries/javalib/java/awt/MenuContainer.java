package java.awt;

public interface MenuContainer {
  Font getFont();
  void remove( MenuComponent c);
}
