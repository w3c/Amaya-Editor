package java.awt;

/**
 * Event - 
 *
 * Copyright (c) 1998
 *      Transvirtual Technologies, Inc.  All rights reserved.
 *
 * See the file "license.terms" for information on usage and redistribution 
 * of this file. 
 *
 * @deprecated
 * This class has been deprecated - use AWTEvent and it's subclasses.
 */

public class Event
{
}
