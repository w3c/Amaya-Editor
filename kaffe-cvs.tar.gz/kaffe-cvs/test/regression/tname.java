class tname {
	public static void main (String args[]) {
		System.out.println("Hello, my name is " + Thread.currentThread().getName());
	}
}

