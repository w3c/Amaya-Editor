class finaltest2 {
  final static double PI = 3.1415926536;
}
