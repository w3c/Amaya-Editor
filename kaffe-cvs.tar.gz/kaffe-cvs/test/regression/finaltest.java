class finaltest2 {
  static double PI = 3.1415926536;
}

public class finaltest {
  public static void main (java.lang.String[] argv) {
    java.lang.System.out.println (finaltest2.PI);
  }
}
