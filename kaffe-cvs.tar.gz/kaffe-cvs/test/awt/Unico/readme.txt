UniCo 1.0

UniCo requires a Java 1.1 Virtual Machine. 

How to use UniCo :
1 Extract the content of unico.zip 
2 Add the path of the file Unico.class to your CLASSPATH environment variable
3 Execute the java class  Unico in your java intepreter 


The files unico.sh, unico.bat, unico.bat can perform the CLASSPATH setting and
start UniCo if they are executed from the directory in wich the Unico.class file is
located. 

unico.sh is for unix
unico.bat is for win95/NT with JDK 1.1 or later
unicoms.bat is for win95/NT with Internet Explorer 4.0 or later

For upgrades and new versions go to
http://arena.sci.univr.it/~poltro/unico

Send comments to
poltro@arena.sci.univr.it









