/*
 * config-setjmp.h
 *
 * Copyright (c) 1996, 1997
 *	Transvirtual Technologies, Inc.  All rights reserved.
 *
 * See the file "license.terms" for information on usage and redistribution 
 * of this file. 
 */

#ifndef __config_setjmp_h
#define __config_setjmp_h

#include <setjmp.h>

#endif
