package w3c.thotlib;

/*
 * Stub classes to interface the Thotlib Presentation accesses from Java
 */


public class Presentation {
}

