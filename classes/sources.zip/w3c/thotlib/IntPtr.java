package w3c.thotlib;

/*
 * Java Classe used for OUT parameters when calling native functions
 */

public class IntPtr {
    protected int value;

    public IntPtr(int val) {
        value = val;
    }

    public int value() {
        return (value);
    }

    /*
     * Indirect access methods from C
     */
    protected int get_value() { return(value); }
    protected void set_value(int val) { value = val; }

}

