package w3c.thotlib;

/*
 * Java Classe associated to an Attribute of an Element.
 */

public class Attribute {
    long attribute;
    private long element = 0;
    public static final int SearchForward = APITree.SearchForward;
    public static final int SearchInTree = APITree.SearchInTree;
    public static final int SearchBackward = APITree.SearchBackward;

    /*
     * These functions just create wrapper classes around existing
     * Thot Attributes.
     */
    public Attribute() {
        attribute = 0;
	element = 0;
    }
    public Attribute(long value) {
// System.out.println("Attribute(long " + value + ")");
        attribute = value;
	element = 0;
    }

    /*
     * These functions create new Attributes in the Thot library and attach
     * them to the Attribute class.
     */
    public Attribute(AttributeType atType) {
	element = 0;
        attribute = Extra.TtaNewAttribute(atType);
    }
    public Attribute(Document doc, int atNo) {
// System.out.println("Attribute(doc " + doc + ", atNo" + atNo + ")");
	long sschema = doc.SSchema();
// System.out.println("sschema : " + sschema);
        AttributeType atType = new AttributeType(sschema, atNo);

        attribute = Extra.TtaNewAttribute(atType);
// System.out.println("attribute : " + attribute);
	element = 0;
    }

    /*
     * This function search of an element handling a given attribute.
     * The search starts with an element passed as the starting point
     * and browse either the subtree of the whole tree (backward or
     * forward).
     */
    public static Attribute SearchAttribute(Element el, int atNo, int scope) {
        if (el == null) return(null);

// System.out.println("Attribute.SearchAttribute(" + el + ", " + atNo +")");

	Document doc = el.Document();
	long sschema = doc.SSchema();
        AttributeType atType = new AttributeType(sschema, atNo);

	Attribute at = new Attribute(0);
	Extra.TtaSearchAttribute(atType, scope, el.element, el, at);

	if ((at.attribute == 0) || (el.element == 0)) return(null);
	at.element = el.element;

	return at;
    }

    /*
     * This function returns an existing Attribute associated to el.
     */
    public static Attribute GetAttribute(Element el, int atNo) {
        if (el == null) return(null);

	Document doc = el.Document();
	long sschema = doc.SSchema();
	AttributeType atType = new AttributeType(sschema, atNo);

        long attribute = Extra.TtaGetAttribute(el.element, atType);
	if (attribute == 0) return(null);

	Attribute at = new Attribute(attribute);
	at.element = el.element;
	return at;
    }

    /*
     * These functions attach and remove Attributes in the Thot library.
     */
    public void Remove(Element el) {
	APIAttribute.TtaRemoveAttribute(el.element, this.attribute, el.DocNo());
	element = 0;
    }
    public void Attach(Element el) {
	APIAttribute.TtaAttachAttribute(el.element, this.attribute, el.DocNo());
	element = el.element;
    }

    /*
     * These functions acess Attributes value in the Thot library
     */
    public void SetValue(Document doc, int value) {
	if (element == 0)
	    APIAttribute.TtaSetAttributeValue(this.attribute, value, 0,
					      doc.document);
        else
	    APIAttribute.TtaSetAttributeValue(this.attribute, value,
	                                      element, doc.document);
    }
    public void SetValue(Element el, int value) {
        APIAttribute.TtaSetAttributeValue(this.attribute, value, el.element,
	                                  el.DocNo());
        element = el.element;
    }
    public void SetValue(Element el, String value) {
        APIAttribute.TtaSetAttributeText(this.attribute, value, el.element,
	                                 el.DocNo());
        element = el.element;
    }
    public void SetValue(Document doc, String value) {
	APIAttribute.TtaSetAttributeText(this.attribute, value, element,
	                                 doc.document);
    }
    public void SetValue(String value) {
        int doc;
        if (element == 0) {
            System.out.println("Attribute.SetValue : attribute has no element");
	    return;
	}
	doc = APITree.TtaGetDocument(element);
	APIAttribute.TtaSetAttributeText(this.attribute, value, element, doc);
    }

    public long GetValue() {
        return APIAttribute.TtaGetAttributeValue(this.attribute);
    }
    public String GetString() {
        IntPtr lenght = new IntPtr(256);
	StringBuffer value = new StringBuffer(256);

	APIAttribute.TtaGiveTextAttributeValue(this.attribute, value, lenght);
        return value.toString();
    }

    /*
     * Print : debugging function.
     */
    public void Print() {
	System.out.println("Attribute " + this);
        if (this.attribute == 0) {
	    System.out.println("Not initialized : attribute == 0");
	    return;
	}
	System.out.println("  Thot attribute at " + this.attribute);
    }

    /*
     * Indirect access methods from C
     */
    protected long get_attribute(long value) { return(attribute); }
    protected void set_attribute(long value) { attribute = value; }
    protected int get_attribute(int value) { return((int)attribute); }
    protected void set_attribute(int value) { attribute = value; }

}


