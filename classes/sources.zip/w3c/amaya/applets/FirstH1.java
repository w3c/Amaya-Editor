/*
 * This is an Applet for Amaya.
 *
 * It prints out the text of the first H1 of the Document every 10 second
 * to give a fancy demo of scripting capabilities.
 */

import w3c.thotlib.*;
import w3c.amaya.*;

class FirstH1 {
    public int main(int document) {
        long elem;

	Document doc = new Document(document);
	Element current = doc.Root();
	ElementType elType = new ElementType(current);
        elType.SetType(APIHtml.HTML_EL_H1);

        while (true) {
	    try {
	       Thread.sleep(1000);
	    }
	    catch (InterruptedException e) {}
	    catch (Exception e) {}
	    catch (Throwable e) {}

            current = doc.Root();
            
	    elem = Extra.TtaSearchTypedElement(elType,
                             APITree.SearchInTree, current);
	    if (elem != 0) {
                current = new Element(elem);
	    }
        }
    }
}
