/*
 * A Link header found at the HTTP level.
 */
package w3c.amaya;

import java.io.*;
import java.util.*;

import w3c.www.http.*;
import w3c.www.protocol.http.*;

import w3c.amaya.*;

/**
 * A class to handle Link in HTTP headers. See HTML 4.0 specification,
 * the HTTP 1.1 RFC 2068, section 19.6.2.4 Link.
 * It provides a constructor parsing the whole list of attributes
 * but currently only keep the link (href), rel, rev, title and anchor
 * values.
 */

public class HTTPLinkHeader {
    public String href = null;
    public String rel = null;
    public String rev = null;
    public String title = null;
    public String anchor = null;
    protected HTTPLinkHeader next = null;

    /**
     * Construct a new set of HTTPLinkHeader objects and
     * initialize them by parsing the HTTP value for the
     * Link header fields.
     * @param value The HTTP Link header field content.
     */

    public HTTPLinkHeader(String value) {
        StringTokenizer st = new StringTokenizer(value, ",");
	String		str;
	HTTPLinkHeader  cur = this;

	try {
	    str = st.nextToken();
	    cur.parse(str);
	} catch (Exception ex) {
	}

	while (st.hasMoreTokens()) {
	    HTTPLinkHeader nextLink = new HTTPLinkHeader();
	    try {
		str = st.nextToken();
		nextLink.parse(str);
		cur.next = nextLink;
		cur = cur.next;
	    } catch (Exception ex) {
	    }
	}
    }
    public HTTPLinkHeader() {
    }

    /**
     * Parse one Link header value and initialize the object
     * @param value One HTTP Link header field
     */
    public void parse(String value) {
        StringTokenizer st = new StringTokenizer(value, " =;,", true);
	int             len   = st.countTokens();
	String          cur;
	String          marker;
	String          val;
	String          tmp;

	while (st.hasMoreTokens()) {
	    try {
		cur = st.nextToken();
		if (cur.equals(";")) continue;
		if (cur.equals("=")) continue;
		if (cur.equals(" ")) continue;
		if (cur.charAt(0) == '<') {
		    int l = cur.length();
		    if (cur.charAt(l - 1) == '>') {
			href = cur.substring(1, l - 1);
			// System.out.println("href = \"" + href + "\"");
			continue;
		    } else 
		        continue; // Error !!! ";" "=" or " " in URI
		}
		if (!st.hasMoreTokens()) {
		    // System.out.println("Singleton \"" + cur + "\"");
		    continue;
		}
		do {
		    marker = st.nextToken();
		} while (marker.equals(" "));
		if (marker.equals(";")) {
		    // System.out.println("Singleton \"" + cur + "\"");
		    continue;
		} else if (marker.equals("=")) {
		    val = st.nextToken();
		    if (val.charAt(0) == '\"') {
			int l = val.length(); 
			while (val.charAt(l - 1) != '\"') {
			    tmp = st.nextToken();
			    val = val + tmp;
			    l = val.length();
			}
			val = val.substring(1, l - 1);
		    }
		} else {
		    // System.out.println("Strange : " + cur + marker);
		    continue;
		}
		// System.out.println("Association " + cur + " = \"" + val + "\"");
                if (cur.equalsIgnoreCase("rev")) rev = val;
                else if (cur.equalsIgnoreCase("rel")) rel = val;
                else if (cur.equalsIgnoreCase("title")) title = val;
                else if (cur.equalsIgnoreCase("anchor")) anchor = val;

            } catch (Exception ex) {
	    }
	}
    }

    /**
     * Handle an HTTPLinkHeader in Amaya
     * Currently we just load stylesheets.
     * @param document the Thot document number.
     */
    public void handle(int document) {
        if (href == null) return;
	if ((rel != null) && (rel.equalsIgnoreCase("stylesheet"))) {
	    System.out.print("Loading Style Sheet : " + href);
	    APIJavaAmaya.AddStyleSheet(href, document);
	} else if ((rel != null) && 
	           (rel.equalsIgnoreCase("alternate stylesheet"))) {
	    System.out.print("Loading Style Sheet : " + href);
	    APIJavaAmaya.AddStyleSheet(href, document);
	} else {
	    print();
	}
    }

    /**
     * Print the content of an HTTPLinkHeader object.
     */
    public void print() {
        boolean start = true;
        if (href != null) {
	    System.out.print("<" + href + ">");
	    start = false;
	}
	if (rel != null) {
	    if (start) start = false;
	    else System.out.print("; ");
	    System.out.print("rel=\"" + rel + "\"");
	}
	if (rev != null) {
	    if (start) start = false;
	    else System.out.print("; ");
	    System.out.print("rev=\"" + rev + "\"");
	}
	if (title != null) {
	    if (start) start = false;
	    else System.out.print("; ");
	    System.out.print("title=\"" + title + "\"");
	}
	if (anchor != null) {
	    if (start) start = false;
	    else System.out.print("; ");
	    System.out.print("anchor=\"" + anchor + "\"");
	}
	System.out.println();
    }

    /**
     * Parse the string argument and prints the result, test for the parser.
     * @param args List of string, only one is parsed.
     */

    public static void main (String args[]) {
        if (args.length == 1) {
	    HTTPLinkHeader result = null;
	    try {
	        result = new HTTPLinkHeader(args[0]) ;
	    } catch (Exception ex) {
	    }
	    System.out.print("Result of parsing : ");
	    result.print();
	} else {
	    System.out.println ("Usage: java HTTPLinkHeader \"link header to parse\"") ;
	}
    }
}

