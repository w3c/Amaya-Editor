/*
 * Filter for grabbing LINK in HTTP header instead of the <HEAD> section of
 * HTML documents.
 */
package w3c.amaya;

import java.io.*;

import w3c.www.http.*;
import w3c.www.protocol.http.*;

import w3c.amaya.*;

public class HTTPLink implements PropRequestFilter {
    /**
     * the HttpManager that installed us.
     */
    protected HttpManager manager = null;

    /**
     * PropRequestFilter implementation - Initialize the filter.
     * Time to register ourself to the HttpManager.
     * @param manager The HTTP manager that is initializing ourself.
     */

    public void initialize(HttpManager manager) {
	this.manager = manager;
	manager.setFilter(this);
    }

    /**
     * This filter don't handle exceptions.
     * @param request The request that triggered the exception.
     * @param ex The triggered exception.
     * @return Always <strong>false</strong>.
     */

    public boolean exceptionFilter(Request request, HttpException ex) {
	return false;
    }

    /**
     * On the way out, we let the request fly through.
     * @param request The request about to be emitted.
     */

    public Reply ingoingFilter(Request request) {
	return null;
    }

    /**
     * Catch any Link HTTP header and store it for later handling
     * in the HTTPRequest associated to this Reply.
     * @param request The request emitted.
     * @param reply The reply.
     * @throw HttpException If some HTTP error occurs.
     */

    public Reply outgoingFilter(Request request, Reply reply) 
	throws HttpException
    {
        if (reply == null) return null;
        if (request == null) return null;
	if (reply.hasHeader("Link")) {
	    String value = (String) reply.getHeaderValue("Link").getValue();
	    if (value == null) return(null);
	    HTTPRequest req = HTTPRequest.HTTPAccessObject.Lookup(request);
	    if (req == null) return(null);

            // Parse the value and add the result at the end of the
	    // linkHeaders list.
	    HTTPLinkHeader link = new HTTPLinkHeader(value);
	    HTTPLinkHeader cur = req.linkHeaders;

	    if (cur == null) req.linkHeaders = link;
	    else {
	        while (cur.next != null) cur = cur.next;
		cur.next = link;
	    }
	}
	return null;
    }

    /**
     * We don't maintain cached informations.
     */

    public void sync() {
    }
}

