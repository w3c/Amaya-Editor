// ResourceFrame.java
// $Id: ResourceFrame.java,v 1.1 1997/03/28 16:18:37 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.store ;

/**
 * Resource frames are extension to resources.
 */

public class ResourceFrame extends Resource {


}
