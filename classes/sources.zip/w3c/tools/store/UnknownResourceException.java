// UnknownResourceException.java
// $Id: UnknownResourceException.java,v 1.1 1997/01/17 09:43:25 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.store ;

public class UnknownResourceException extends RuntimeException {

    public UnknownResourceException (Resource resource) {
	super("ResourceStore mismatch for resource "+resource.getIdentifier());
    }

}
