// ChildNotSupportedException.java
// $Id: ChildNotSupportedException.java,v 1.3 1997/07/30 14:02:52 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources;

/**
 * Get thrown if a container resource refuse a given type of child.
 */

public class ChildNotSupportedException extends Exception {

    public ChildNotSupportedException(String msg) {
	super(msg);
    }

}
