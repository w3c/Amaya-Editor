// Main.java
// $Id: Main.java,v 1.2 1997/07/30 14:08:49 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package resources.rmi;

import java.rmi.*;

// For fun only !

public class Main {

    public static void main(String args[]) {
	System.setSecurityManager (new RMISecurityManager());
	try {
	    String server = args[0];
	    String name   = args[1];
	    String path   = args[2];
	    RemoteResourceSpace space = ((RemoteResourceSpace)
					 Naming.lookup("//"+server+"/"+name));
	    RemoteResource resource   = space.resolve(path);
	    System.out.println(resource+" name="
			       + resource.getValue("name"));
	} catch (Exception ex) {
	    ex.printStackTrace();
	}

    }

}
