// RemoteResourceContainer.java
// $Id: RemoteResourceContainer.java,v 1.3 1997/07/30 14:09:09 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.rmi;

import java.rmi.*;
import w3c.tools.resources.*;

public interface RemoteResourceContainer extends RemoteResource {

    
    public void registerChild(Resource resource, ResourceContext ctxt)
	throws RemoteException
    , ChildNotSupportedException
    , ResourceInitException;

    public void deleteChild(Resource child)
	throws RemoteException;

    public void deleteChild(String name)
	throws RemoteException;

    public String[] listChildNames()
	throws RemoteException;

    public RemoteResource[] listChildren()
	throws RemoteException;
}

