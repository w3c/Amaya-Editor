// RemoteResource.java
// $Id: RemoteResource.java,v 1.3 1997/07/30 14:09:03 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.rmi;

public interface RemoteResource extends java.rmi.Remote {

    public RemotePropertyDescriptor[] getProperties() 
	throws java.rmi.RemoteException;

    public Object getValue(String name)
	throws java.rmi.RemoteException
             , IllegalAccessException
             , IllegalArgumentException;

    public Object[] getValues(String names[])
	throws java.rmi.RemoteException
             , IllegalAccessException
             , IllegalArgumentException;

    public void setValue(String name, Object value) 
	throws java.rmi.RemoteException
             , IllegalAccessException
             , IllegalArgumentException;

    public void setValues(String names[], Object values[]) 
	throws java.rmi.RemoteException
             , IllegalAccessException
             , IllegalArgumentException;

    public void destroy()
	throws java.rmi.RemoteException;

    public RemoteResource resolve(String name) 
	throws java.rmi.RemoteException;

    public RemoteResource[] getDelegatees() 
	throws java.rmi.RemoteException;

}
