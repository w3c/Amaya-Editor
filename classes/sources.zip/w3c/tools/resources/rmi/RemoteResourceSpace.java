// RemoteResourceSpace.java
// $Id: RemoteResourceSpace.java,v 1.3 1997/07/30 14:09:24 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.rmi;

import java.rmi.*;

import w3c.tools.resources.*;

public interface RemoteResourceSpace extends Remote {

    /**
     * Get a stub to manipulate a resource.
     * @param path The resource path.
     * @return A resource stub.
     */

    public RemoteResource resolve(String path)
	throws RemoteException;

}
