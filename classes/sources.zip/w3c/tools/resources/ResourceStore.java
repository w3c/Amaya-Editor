// ResourceStore.java
// $Id: ResourceStore.java,v 1.3 1997/07/30 14:04:00 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources;

import java.util.*;
import java.io.*;

import w3c.tools.resources.*;

public interface ResourceStore {
  
  public PersistentReference getPersistentReference (String resource);

  public Enumeration listResourceName();

  public File getResourceFile(String name);

  public File getDirectory();

  public void init(String init)
    throws ResourceStoreInitException;

  public ResourceStore addStore(String name)
    throws ResourceStoreInitException;

  public ResourceStore getNewStore(File directory)
    throws ResourceStoreInitException;

}
