// ConvertFile.java
// $Id: ConvertFile.java,v 1.2 1997/07/30 14:05:24 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.converter;

import java.io.*;

public class ConvertFile implements Convert {

  public void setInitialClass(Class c){}

  public Object defaultValue() {
    return new File("");
  }

  public String toString(Object O) {
    return ((File)O).getAbsolutePath();
  }

  public Object toObject(String S) {
    return new File(S);
  }

  public Class classConverted() {
    try {
      return Class.forName("java.io.File");
    } catch (ClassNotFoundException ex) {
      System.out.println(ex.getMessage());
      ex.printStackTrace();
      return null;
    }
  }

}
