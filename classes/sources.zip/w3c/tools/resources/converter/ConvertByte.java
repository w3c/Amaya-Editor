// ConvertByte.java
// $Id: ConvertByte.java,v 1.2 1997/07/30 14:05:14 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.converter;

public class ConvertByte implements Convert {

  public void setInitialClass(Class c){}

  public Object defaultValue() {
    return new Byte("0");
  }

  public String toString(Object O) {
    return String.valueOf(O);
  }

  public Object toObject(String S) {
    return new Byte(S);
  }

  public Class classConverted() {
    try {
      return Class.forName("java.lang.Byte");
    } catch (ClassNotFoundException ex) {
      System.out.println(ex.getMessage());
      ex.printStackTrace();
      return null;
    }
  }

}
