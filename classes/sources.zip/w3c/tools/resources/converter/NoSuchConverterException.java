// NoSuchConverterException.java
// $Id: NoSuchConverterException.java,v 1.2 1997/07/30 14:06:13 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.converter;

public class NoSuchConverterException extends Exception {

    NoSuchConverterException(String msg) {
	super(msg);
    }

}
