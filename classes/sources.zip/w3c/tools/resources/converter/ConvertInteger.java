// ConvertInteger.java
// $Id: ConvertInteger.java,v 1.2 1997/07/30 14:05:33 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.converter;

public class ConvertInteger implements Convert {

  public void setInitialClass(Class c){}

  public Object defaultValue() {
    return new Integer(-1);
  }

  public String toString(Object O) {
    return String.valueOf(O);
  }

  public Object toObject(String S) {
    return new Integer(S);
  }

  public Class classConverted() {
    try {
      return Class.forName("java.lang.Integer");
    } catch (ClassNotFoundException ex) {
      System.out.println(ex.getMessage());
      ex.printStackTrace();
      return null;
    }
  }

}
