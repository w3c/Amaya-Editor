// PersistentReferenceImpl.java
// $Id: PersistentReferenceImpl.java,v 1.2 1997/07/30 14:07:06 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.impl;
 
import w3c.tools.resources.PersistentReference;
 

public class PersistentReferenceImpl implements PersistentReference {
    public String containerPath     = null;
    public String resourceName  = null;
 
    public int hashCode() {
        return containerPath.hashCode() ^ resourceName.hashCode();
    }
 
    public PersistentReferenceImpl(String containerPath, String resourceName) {
        this.containerPath = containerPath;
        this.resourceName = resourceName;
    }
 
}
