// CacheRevalidator.java
// $Id: CacheRevalidator.java,v 1.4 1997/07/30 14:07:01 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.impl ;

import w3c.tools.resources.*;

public interface CacheRevalidator {

    public w3c.tools.resources.Resource revalidate(PersistentReference pr);

}
