// PersistentReference.java
// $Id: PersistentReference.java,v 1.2 1997/07/30 14:03:02 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources;

/**
 * Provide a way to find a resource in a resource space
 */
public interface PersistentReference {


}
