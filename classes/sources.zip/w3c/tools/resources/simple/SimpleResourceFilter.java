// SimpleResourceFilter.java
// $Id: SimpleResourceFilter.java,v 1.2 1997/07/30 14:09:45 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.simple;

import java.io.*;

/**
 * The FilenameFilter for Simple Resources Files.
 */

public class SimpleResourceFilter implements FilenameFilter {


  /**
   * Tests if a specified file should be included in a file list. 
   * @param dir - the directory in which the file was found. 
   *        name - the name of the file. 
   * @return true if the name should be included in the file list; 
   * false otherwise.
   */
  public boolean accept(File dir, String name) {
    File f = new File(dir,name);
    if (f.isDirectory()) return false;
    String ext = name.substring(name.length()-2);
    if (ext.equals(".s")) return true;
    return false;
  }

}
