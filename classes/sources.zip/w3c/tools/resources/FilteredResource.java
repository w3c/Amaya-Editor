// FilteredResource.java
// $Id: FilteredResource.java,v 1.1 1997/06/10 12:14:32 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources ;

import java.util.*;

public interface FilteredResource extends Resource {

    public ResourceReference[] getFilters();
    public ResourceReference[] getFilters(Class cls);
    public void registerFilter(ResourceReference filter, Hashtable defs);
    public void unregisterFilter(ResourceReference filter);

}
    
