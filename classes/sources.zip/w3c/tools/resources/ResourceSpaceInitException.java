// ResourceSpaceInitException.java
// $Id: ResourceSpaceInitException.java,v 1.2 1997/07/30 14:03:50 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources;

public class ResourceSpaceInitException extends Exception {

    public ResourceSpaceInitException(String msg) {
	super(msg);
    }

}
