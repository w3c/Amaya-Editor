// AttributeChangedListener.java
// $Id: AttributeChangedListener.java,v 1.3 1997/07/30 14:06:29 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.event;

import java.util.*;

public interface AttributeChangedListener extends EventListener {

    /**
     * Gets called when a property changes.
     * @param evt The AttributeChangeEvent describing the change.
     */

    public void attributeChanged(AttributeChangedEvent evt);

}
