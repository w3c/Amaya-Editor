// AttributeChangedEvent.java
// $Id: AttributeChangedEvent.java,v 1.3 1997/07/30 14:06:24 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.event;

import java.beans.*;

import w3c.tools.resources.*;

public class AttributeChangedEvent extends PropertyChangeEvent {

    /**
     * Create an attribute change event.
     * @param source The resource whose attribute has changed.
     * @param name The name of the attribute that has changed.
     * @param oldvalue The old attribute value.
     * @param newvalue The new attribuyte value.
     */

    public AttributeChangedEvent(Resource source, String name
				 , Object oldvalue, Object newvalue) {
	super(source, name, oldvalue, newvalue);
    }

}
