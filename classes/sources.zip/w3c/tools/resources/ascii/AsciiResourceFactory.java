// AsciiResourceFactory.java
// $Id: AsciiResourceFactory.java,v 1.5 1997/07/30 14:04:42 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.resources.ascii;

import w3c.tools.resources.*;

/**
 * The interface to convert <em>items</em> into a resource.
 */

public interface AsciiResourceFactory {

  public java.util.Enumeration getProperties();

  public Object[] readResource(String items[], int off, int len)
    throws ResourceInitException;

  public String writeResource(Object values[]);

  public Object[] getDefaultValues();

  public Object getValue(Object values[], String name)
    throws IllegalAccessException, IllegalArgumentException;

  public Object[] getValues(Object values[], String names[])
    throws IllegalAccessException, IllegalArgumentException;

  public void setValue(Object values[], String name, Object value)
    throws IllegalAccessException, IllegalArgumentException;

  public void setValues(Object values[], String names[], Object newvalues[])
    throws IllegalAccessException, IllegalArgumentException;
	
}
