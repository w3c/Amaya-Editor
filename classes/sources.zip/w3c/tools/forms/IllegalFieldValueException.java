// IllegalFieldValueException.java
// $Id: IllegalFieldValueException.java,v 1.1 1996/04/10 13:57:04 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.tools.forms ;

/**
 * This exception is thrown when a field is set to an invalid value.
 */

public class IllegalFieldValueException extends Exception {
    IllegalFieldValueException (Object arg) {
	super("illegal value: "+arg) ;
    }
}
