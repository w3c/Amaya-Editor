// FormProcessingException.java
// $Id: FormProcessingException.java,v 1.1 1996/04/10 13:41:51 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.forms ;

/**
 * This exception is throw by form handlers, while encountering errors.
 */

public class FormProcessingException extends Exception {
    public FormProcessingException (String msg) {
	super(msg) ;
    }

}
