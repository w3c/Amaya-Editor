// URLDecoderException.java
// $Id: URLDecoderException.java,v 1.1 1996/10/03 21:18:27 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.forms ;

public class URLDecoderException extends Exception {
    URLDecoderException (String msg) {
	super (msg) ;
    }
}

