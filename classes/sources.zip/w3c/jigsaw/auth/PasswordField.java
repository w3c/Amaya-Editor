// PasswordField.java 
// $Id: PasswordField.java,v 1.1 1996/04/10 13:38:18 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.auth;

import w3c.jigsaw.forms.*;
import w3c.jigsaw.html.*;

public class PasswordField extends TextField {

    /**
     * Dump this field has a form element.
     * @param into The HtmlGenerator to dump the field to.
     */

    public void dump (HtmlGenerator into) {
	dumpTitle(into) ;
	String value = (String) getValue() ;
	into.append ("<th align=left><input type=\"password\""
		     + " name=\""+getName()+"\""
		     + " size=\"32\""
		     + " value=\""
		     + ((value == null) ? "" : value)
		     + "\"></th>") ;
    }

    public PasswordField(String name, String title, String url, String pwd) {
	super(name, title, url, pwd) ;
    }

    public PasswordField() {
    }

}
