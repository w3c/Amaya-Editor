// PasswordAttribute.java
// $Id: PasswordAttribute.java,v 1.4 1997/01/17 09:48:53 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.auth ;

import w3c.tools.store.*;
import w3c.jigsaw.resources.* ;
import w3c.jigsaw.formedit.FormFieldRegistry;

public class PasswordAttribute extends StringAttribute {

    static {
	// Register the associated form field
	FormFieldRegistry.registerField("w3c.jigsaw.auth.PasswordAttribute"
					, "w3c.jigsaw.auth.PasswordField");
    }

    public PasswordAttribute(String name, String password, int flags) {
	super(name, password, flags);
	this.type = "java.lang.String";
    }

}
