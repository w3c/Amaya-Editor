// InvalidResourceClass.java 
// $Id: InvalidResourceClass.java,v 1.2 1997/07/30 12:06:12 ylafon Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.admin;

/**
 * The exception for invalid classes.
 */

public class InvalidResourceClass extends Exception {

    public InvalidResourceClass(String msg) {
	super(msg);
    }

}
