// AdminProtocolException.java
// $Id: AdminProtocolException.java,v 1.2 1997/07/30 12:03:48 ylafon Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.admin;

public class AdminProtocolException extends Exception {
    
    AdminProtocolException(String msg) {
	super(msg);
    }

}
