// AdminProtocol.java
// $Id: AdminProtocol.java,v 1.2 1997/07/30 12:03:11 ylafon Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.admin;

public interface AdminProtocol {

    public static final byte WIRED_PLAIN    = (byte) 1;
    public static final byte WIRED_FILTERED = (byte) 2;
}
