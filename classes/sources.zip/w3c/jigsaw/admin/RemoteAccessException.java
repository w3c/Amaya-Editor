// RemoteAccessException.java
// $Id: RemoteAccessException.java,v 1.2 1997/02/26 16:56:22 ylafon Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.admin;

/**
 * The exception for network failure.
 */

public class RemoteAccessException extends Exception {

    public RemoteAccessException(String msg) {
	super(msg);
    }

}
