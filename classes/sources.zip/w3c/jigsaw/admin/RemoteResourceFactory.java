// RemoteResourceFactory.java 
// $Id: RemoteResourceFactory.java,v 1.4 1997/07/30 12:07:21 ylafon Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.admin;

import java.net.URL;

public class RemoteResourceFactory {
    AdminContext admin = null;

    public RemoteResource createRemoteResource(URL parent
					       , String identifier
					       , String clsnames[]) {
	return new PlainRemoteResource(admin, parent, identifier, clsnames);
    }

    public RemoteResource createRemoteResource(URL url, String classes[]) {
	return new PlainRemoteResource(admin, null, null, url, classes);
    }

    RemoteResourceFactory(AdminContext admin) {
	this.admin = admin;
    }

}
