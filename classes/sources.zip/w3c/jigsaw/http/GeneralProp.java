// GeneralProp.java
// $Id: GeneralProp.java,v 1.9 1997/03/12 10:50:10 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.http;

import java.io.* ;
import java.util.* ;

import w3c.tools.store.*;
import w3c.www.http.*;
import w3c.jigsaw.resources.* ;
import w3c.jigsaw.forms.* ;
import w3c.jigsaw.daemon.*;
import w3c.jigsaw.config.*;

/**
 * A wrapper class to give access to editable properties through a resource.
 * This class allows to reuse entirely the generic resource editor to
 * edit the properties of the server.
 */

class GeneralProp extends PropertySet {
    private static final String title = "General properties";

    static {
	Class     c = null;
	Attribute a = null;

	try {
	    c = Class.forName("w3c.jigsaw.http.GeneralProp");
	} catch (Exception ex) {
	    ex.printStackTrace();
	    System.exit(1);
	}
	// The server name:
	a = new StringAttribute(httpd.SERVER_SOFTWARE_P
				, null
				, Attribute.EDITABLE);
	AttributeRegistry.registerAttribute(c, a);
	// Is the file system case sensitive ?
	a = new BooleanAttribute(httpd.FS_SENSITIVITY
				 , null
				 , Attribute.EDITABLE);
	AttributeRegistry.registerAttribute(c, a);
	// The server root directory:
	a = new FileAttribute(httpd.ROOT_P
			      , null
			      , Attribute.EDITABLE);
	AttributeRegistry.registerAttribute(c, a);
	// The full host name:
	a = new StringAttribute(httpd.HOST_P
				, null
				, Attribute.EDITABLE);
	AttributeRegistry.registerAttribute(c, a);
	// The port number:
	a = new IntegerAttribute(httpd.PORT_P
				 , null
				 , Attribute.EDITABLE);
	AttributeRegistry.registerAttribute(c, a);
	// The root store name:
	a = new FileAttribute(httpd.ROOT_STORE_P
			      , null
			      , Attribute.EDITABLE);
	AttributeRegistry.registerAttribute(c, a);
	// The root resource identifier:
	a = new StringAttribute(httpd.ROOT_NAME_P
				, null
				, Attribute.EDITABLE);
	AttributeRegistry.registerAttribute(c, a);
	// The list of public methods:
	a = new StringArrayAttribute(httpd.PUBLIC_P
				     , null
				     , Attribute.EDITABLE);
	AttributeRegistry.registerAttribute(c, a);
	// The trace flag:
	a = new BooleanAttribute(httpd.TRACE_P
				 , null
				 , Attribute.EDITABLE);
	AttributeRegistry.registerAttribute(c, a);
	// The documentation path:
	a = new StringAttribute(httpd.DOCURL_P
				, null
				, Attribute.EDITABLE);
	AttributeRegistry.registerAttribute(c, a);
    }

    /**
     * This property set's title.
     * @return A String encoded title.
     */

    public String getTitle() {
	return title;
    }

    GeneralProp(String name, httpd server) {
	super(name, server);
    }
}

