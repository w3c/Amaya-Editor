// CvsHandlerInterface.java
// $Id: CvsHandlerInterface.java,v 1.4 1997/01/08 17:13:15 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.cvs ;

import w3c.jigsaw.http.* ;
import w3c.cvs.* ;

public interface CvsHandlerInterface {

    /**
     * Perform action on the given cvs entry, on behalf of the given client.
     * @param request The request to handle.
     * @param action The action to perform.
     * @param entry The entry to act on.
     * @param direntries the directories to act on
     * @exception HTTPException If the action couldn't be performed.
     */

    public void perform (Request request
			 , String action
			 , String names[])
	throws HTTPException ;
    
    /**
     * Perform action on the given cvs entry, on behalf of the given client.
     * @param request The request that triggered the processing.
     * @param action The action to perform.
     * @param entry The entry to act on.
     * @param direntries the directories to act on
     * @param comment Some comments describing your changes.
     * @exception HTTPException If the action couldn't be performed.
     */

    public void perform (Request request
			 , String action
			 , String names[]
			 , String comment)
	throws HTTPException ;
    

}
