// MapException.java
// $Id: MapException.java,v 1.3 1996/08/18 19:18:28 anto Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.map;

class MapException extends RuntimeException {
    public MapException(String msg)
    {
	super(msg);
    }
}

