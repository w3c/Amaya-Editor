// LinkFilter.java
// $Id:$
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.contrib;

import java.net.*;

import w3c.tools.store.*;
import w3c.www.http.*;
import w3c.www.mime.*;
import w3c.jigsaw.http.*;
import w3c.jigsaw.resources.*;

/**
 * Enforces a specific Link value on all replies iif the Content-Type
 * is text/html.
 */

public class LinkFilter extends ResourceFilter {
    /**
     * Href index - The href value
     */
    protected static int ATTR_HREF_VALUE = -1;
    /**
     * Rel index - The relationship value.
     */
    protected static int ATTR_REL_VALUE = -1;
    /**
     * Rev index - The revision value
     */
    protected static int ATTR_REV_VALUE = -1;
    /**
     * Title index - The title value
     */
    protected static int ATTR_TITLE_VALUE = -1;
    /**
     * Anchor index - The anchor value
     */
    protected static int ATTR_ANCHOR_VALUE = -1;
    /**
     * MimeType index - The Mime type selector
     */
    protected static int ATTR_MIME_TYPE_SELECTOR = -1;

    static {
	Class c = null;
	Attribute a = null;
	try {
	    c = Class.forName("w3c.jigsaw.contrib.LinkFilter");
	} catch (Exception ex) {
	    ex.printStackTrace();
	    System.exit(1);
	}
	// Register the href value attribute.
	a = new StringAttribute("href"
				, null
				, Attribute.EDITABLE);
	ATTR_HREF_VALUE = AttributeRegistry.registerAttribute(c, a);
	// Register the rel value attribute.
	a = new StringAttribute("rel"
				, null
				, Attribute.EDITABLE);
	ATTR_REL_VALUE = AttributeRegistry.registerAttribute(c, a);
	// Register the rev value attribute.
	a = new StringAttribute("rev"
				, null
				, Attribute.EDITABLE);
	ATTR_REV_VALUE = AttributeRegistry.registerAttribute(c, a);
	// Register the title value attribute.
	a = new StringAttribute("title"
				, null
				, Attribute.EDITABLE);
	ATTR_TITLE_VALUE = AttributeRegistry.registerAttribute(c, a);
	// Register the anchor value attribute.
	a = new StringAttribute("anchor"
				, null
				, Attribute.EDITABLE);
	ATTR_ANCHOR_VALUE = AttributeRegistry.registerAttribute(c, a);
	// Register the Mime type selector
	a = new StringAttribute("mimetype-selector"
				, null
				, Attribute.EDITABLE);
	ATTR_MIME_TYPE_SELECTOR = AttributeRegistry.registerAttribute(c, a);
    }

	
    /**
     * Get the header value to set, if any.
     * @return A String encoded value for the header to set, or <strong>
     * null</strong>.
     */
    
    public String getHeaderValue() {
        String href = getString(ATTR_HREF_VALUE, null);
        String rel = getString(ATTR_REL_VALUE, null);
        String rev = getString(ATTR_REV_VALUE, null);
        String title = getString(ATTR_TITLE_VALUE, null);
        String anchor = getString(ATTR_ANCHOR_VALUE, null);
	String result = null;
	if (href != null) {
	    if (result == null) result = "<" + href +">";
	    else result = result + "; <" + href +">";
	}
	if (rel != null) {
	    if (result == null) result = "rel=\"" + rel +"\"";
	    else result = result + "; rel=\"" + rel +"\"";
	}
	if (rev != null) {
	    if (result == null) result = "rev=\"" + rev +"\"";
	    else result = result + "; rev=\"" + rev +"\"";
	}
	if (title != null) {
	    if (result == null) result = "title=\"" + title +"\"";
	    else result = result + "; title=\"" + title +"\"";
	}
	if (anchor != null) {
	    if (result == null) result = "anchor=\"" + href +"\"";
	    else result = result + "; anchor=\"" + href +"\"";
	}
	return(result);
    }

    public Reply ingoingFilter(Request request) {
	return null;
    }

    /**
     * The outgoing filter first check that the Content-Type is
     * match with any Mime type selector and then
     * add the Link: header in the reply.
     * @param request The original request.
     * @param reply The originial reply.
     * @return Always <strong>null</strong>.
     */

    public Reply outgoingFilter(Request request, Reply reply) {
	String mimeTypeSelector = getString(ATTR_MIME_TYPE_SELECTOR, null);
	if (mimeTypeSelector != null) {
	    MimeType mimeType = reply.getContentType();
	    MimeType selector;
	    try {
		selector = new MimeType(mimeTypeSelector);
	    } catch (MimeTypeFormatException ex) {
		return null;
	    }
	    if ((mimeType == null) || (selector == null)) return null;
	    if (selector.match(mimeType) < mimeType.MATCH_SUBTYPE) return null;
	}
	String hvalue = getHeaderValue();
	String val = reply.getValue("link");
	if (val == null)
	    reply.setValue("link", hvalue);
	else
	    reply.setValue("link", val + ", " + hvalue);
	return null;
    }
}


   
     
