// ServerHandlerInitException.java
// $Id: ServerHandlerInitException.java,v 1.1 1996/07/20 00:03:54 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.daemon;

public class ServerHandlerInitException extends Exception {
    
    public ServerHandlerInitException(String msg) {
	super(msg);
    }
}
