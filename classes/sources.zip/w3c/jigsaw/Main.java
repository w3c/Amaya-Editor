// Main.java
// $Id: Main.java,v 1.2 1997/07/30 13:59:22 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw;

/**
 * A place holder for running Jigsaw.
 */

public class Main {

    public static void main(String args[]) {
	w3c.jigsaw.daemon.ServerHandlerManager.main(args);
    }

}
