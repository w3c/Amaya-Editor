// TemplateContainer.java
// $Id: TemplateContainer.java,v 1.3 1997/07/30 14:00:25 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.indexer;

import java.util.*;
import java.io.*;

import w3c.tools.store.*;
import w3c.jigsaw.resources.*;

public class TemplateContainer extends SampleContainer {
    Hashtable defs = null;

    protected Hashtable getDefaultAttributes() {
	return this.defs;
    }

    public TemplateContainer(ResourceContext context, String id) {
	super(id
	      , context.getServer().getResourceStoreManager()
	      , new File(context.getServer().getIndexerDirectory(), id));
	this.defs = new Hashtable(3);
	this.defs.put("context", context);
    }

}
