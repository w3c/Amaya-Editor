// InvalidLabelException.java
// $Id: InvalidLabelException.java,v 1.1 1997/05/21 12:54:55 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.pics ;

public class InvalidLabelException extends Exception {
    
    public InvalidLabelException (String msg) {
	super (msg) ;
    }

    public InvalidLabelException (int lineno, String msg) {
      this ("[" + lineno + "]" + ": " + msg) ;
    }
}
