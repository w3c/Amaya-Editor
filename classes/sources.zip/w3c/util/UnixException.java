// UnixException.java
// $Id: UnixException.java,v 1.3 1997/07/30 14:10:52 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.util;

public class UnixException extends Exception {

    UnixException(String msg) {
	super(msg);
    }

}
