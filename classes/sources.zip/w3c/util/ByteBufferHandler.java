package w3c.util;

public interface ByteBufferHandler {
    
    public int consume(byte buf[], int off, int len);

}
