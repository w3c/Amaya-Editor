// MICPMessage.java
// $Id: MICPMessage.java,v 1.2 1997/07/30 14:12:19 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.www.protocol.http.micp;

public class MICPMessage {
    public int    version = -1;
    public int    op      = -1;
    public int    src     = -1;
    public int    id      = -1;
    public String url     = null;
}
