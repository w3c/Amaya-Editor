/*
 *  MultipleValueAccessException.java
 *
 *  Copyright 1997 Massachusetts Institute of Technology.
 *  All Rights Reserved.
 *
 *  Author: Ora Lassila
 *
 *  $Id: MultipleValueAccessException.java,v 1.1 1997/05/30 13:23:15 bmahe Exp $
 */

package w3c.www.pics;

public class MultipleValueAccessException extends Exception {

  public MultipleValueAccessException()
  {
    super("Rating has more than one value");
  }

}
