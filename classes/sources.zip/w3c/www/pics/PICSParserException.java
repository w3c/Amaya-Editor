/*
 *  PICSParserException.java
 *
 *  Copyright 1997 Massachusetts Institute of Technology.
 *  All Rights Reserved.
 *
 *  Author: Ora Lassila
 *
 *  $Id: PICSParserException.java,v 1.1 1997/05/30 13:23:38 bmahe Exp $
 */

package w3c.www.pics;

import w3c.tools.sexpr.SExprParserException;

public class PICSParserException extends SExprParserException {

  private Exception original;

  public PICSParserException(String explanation)
  {
    super(explanation);
    this.original = null;
  }

  public PICSParserException(String explanation, Exception original)
  {
    super(explanation);
    this.original = original;
  }

  public Exception getOriginal()
  {
    return original;
  }

}
