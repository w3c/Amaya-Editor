/*
 *  Mapper.java
 *
 *  Copyright 1997 Massachusetts Institute of Technology.
 *  All Rights Reserved.
 *
 *  Author: Ora Lassila
 *
 *  $Id: Mapper.java,v 1.1 1997/05/30 13:23:07 bmahe Exp $
 */

package w3c.www.pics;

public interface Mapper {

  public Object map(Object value) throws PICSParserException;

}
