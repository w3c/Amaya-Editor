// MimeType.java
// $Id: MimeTypeFormatException.java,v 1.1 1996/07/08 18:55:06 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.www.mime ;

public class MimeTypeFormatException extends Exception {

    public MimeTypeFormatException(String msg) {
	super(msg);
    }

}
