// SapProtocolException.java
// $Id: SapProtocolException.java,v 1.1 1997/02/25 11:02:43 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.www.sap;

public class SapProtocolException extends Exception {

    public SapProtocolException(String msg) {
	super(msg);
    }

}
