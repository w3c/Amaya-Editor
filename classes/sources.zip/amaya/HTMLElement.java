/*
 * HTMLElement : This class offers an API to manipulate 
 *              called by the Amaya program when remote accesses are
 *              needed.
 */
package amaya;

import amaya.*;
import thotlib.*;

public class HTMLElement {

       /*
        * Extra creation routines
	*/
       static public Element Create(Document doc, String name) {
	   Element el = null;
           int type = APIJavaAmaya.GetHTMLtypeNo(name);
	   if (type != 0) {
	       el = new Element(doc, type);
	   } else {
	       System.out.println("Unknown HTML element : " + name);
	   }
	   return(el);
       }
       static public Element Create(int docNo, String name) {
	   Element el = null;
           int type = APIJavaAmaya.GetHTMLtypeNo(name);
	   if (type != 0) {
	       el = new Element(docNo, type);
	   } else {
	       System.out.println("Unknown HTML element : " + name);
	   }
	   return(el);
       }
       static public int Type(int docNo, String name) {
           int type = APIJavaAmaya.GetHTMLtypeNo(name);
	   if (type == 0) {
	       System.out.println("Unknown HTML element : " + name);
	   }
	   return(type);
       }
}
