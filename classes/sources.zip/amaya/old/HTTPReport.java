package amaya;

import java.io.*;

import w3c.www.protocol.http.*;

public class HTTPReport {
    String url;
    String filename;
    String mimetype;
    int contentlength;
    int currentlength;
    int status; // -1 while not finished.

    // public abstract void Stop();

    HTTPReport(File file, Request request, Reply reply) {
	this.url            = request.getURL().toExternalForm();
	this.filename       = file.getAbsolutePath();
	this.mimetype       = ((reply.getContentType() != null) 
			       ? reply.getContentType().toString()
			       : null);
	this.contentlength  = reply.getContentLength();
	this.status         = reply.getStatus();
	    
    }
}

