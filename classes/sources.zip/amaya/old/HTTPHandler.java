package amaya;

import java.net.*;
import java.io.*;
import java.util.*;

import w3c.www.protocol.http.*;
import w3c.www.mime.*;

/**
 * Because of the raw support in JDK/1.0.2 I had to really jump into
 * Jigsaw low level API. Under Java1.1, however these could probably
 * be rewritten without dependances against Jigsaw specific code.
 */

public class HTTPHandler {
    /**
     * The HttpManager to be used by the HTTP handler (Jigsaw specific)
     */
    protected static HttpManager manager = null;
    /**
     * Did we initialize successfully ?
     */
    protected static boolean erred = true;

    /**
     * Check for an error, if so, emit appropriate exception.
     * @exception HTTPException If an error was detected (ie that object will
     * not work).
     */
    
    protected static void error(String msg) {
	// This ought to be an HTTPException ... FIXME
	throw new RuntimeException("HTTPHandler : " + msg);
    }

    /**
     * Get and initialize the HTTP manager.
     * @param props The properties to init from.
     * @return An HttpManager instance.
     */

    protected final HttpManager getManager() {
	if ( manager == null )
	    error("no manager initialized !");
	return manager;
    }

    /**
     * Get a temporary file.
     * @return A temporary File instance
     */

    protected String hard = null; // DEBUG
    protected File getTempFile() {
	return (hard != null) ? new File(hard) : new File("/tmp/xxx.tst");
    }

    /**
     * Build a report out of te given reply.
     * @param r The reply out of which we have to build a report.
     * @return An HTTPReport instance.
     * @exception HTTPException FIXME
     */

    protected HTTPReport makeReport(Request rq, Reply rp) {
	InputStream  in  = null;
	OutputStream out = null;
	try {
	    File  tmp = getTempFile();
	    byte  b[] = new byte[2048];
	    int   n   = 0;
	    // Setup the streams:
	    if ((in  = rp.getInputStream()) != null) {
		out = new FileOutputStream(tmp);
		// Swallow the content into the file:
		while ((n = in.read(b, 0, b.length)) > 0) 
		    out.write(b, 0, n);
		in.close();  
		in  = null;
		// Generate the report:
		out.close(); 
		out = null;
	    }
	    return new HTTPReport(tmp, rq, rp);
	} catch (Exception ex) {
	    error("unable to generate report !");
	} finally {
	    if ( in != null ) { try { in.close(); } catch (Exception e) {}}
	    if ( out != null ) { try { out.close(); } catch (Exception e) {}}
	}
	// not reached
	return null;
    }

    /**
     * Initalize the HTTP manager from given properties file.
     * @param filename Name of the property file (may be <strong>null</strong>
     * in which case system properties are used).
     */
    
    public static void initialize(String filename) {
        System.out.println("HTTPHandler.initialize()");
	Properties p = new Properties(System.getProperties());
	if ( filename != null ) {
	    try {
	        FileInputStream in = new FileInputStream(new File(filename));
		p.load(new BufferedInputStream(in));
		in.close();
		in = null;
		erred = false;
	    } catch (Exception ex) {
		error("unable to load properties from \""+filename+"\"");
	    }
	}
	manager = HttpManager.getManager(p);
    }

    /**
     * Get the given URL, and save it to a temp file.
     * @return An HTTPReport instance.
     * @exception HTTPException (currently not thrown, FIXME)
     */

    public HTTPReport get(String url, String MimeType) {
	InputStream  in  = null;
	OutputStream out = null;
	// File         tmp = getTempFile();
	try {
	    HttpManager m  = getManager();
	    Request     rq = m.createRequest();
	    rq.setURL(new URL(url));
	    rq.setMethod("GET");
	    // Execute the request:
	    Reply rp = m.runRequest(rq);
	    return makeReport(rq, rp);
	} catch (Exception ex) {
	    error("error while fetching "+url+": "+ex.getMessage());
	} finally {
	    // Make sure any stream gets really closed:
	    if ( in  != null ) { try { in.close(); } catch (Exception ex) {}}
	    if ( out != null ) { try { out.close(); } catch (Exception ex) {}}
	}
	// Not reached !
	return null;
    }
    
    /**
     * POST the given content to the given URL.
     * @param url The target URL.
     * @param mimetype The type of the posted data.
     * @param content The post data.
     * @exception HTTPException FIXME will throw a runtime exception !
     */

    public HTTPReport post(String url
			   , String mimetype
			   , String content) {
	try {
	    HttpManager m  = getManager();
	    Request     rq = m.createRequest();
	    rq.setURL(new URL(url));
	    rq.setMethod("POST");
	    rq.setContentLength(content.length());
	    rq.setContentType(new MimeType(mimetype));
	    rq.setOutputStream(new StringBufferInputStream(content));
	    // Execute the request and swallow output in tmp file:
	    Reply rp = m.runRequest(rq);
	    return makeReport(rq, rp);
	} catch (Exception ex) {
	    error("error while post'ing to "+url+": "+ex.getMessage());
	} 
	// Not Reached:
	return null;
    }

    /**
     * Put the given file to the given URL.
     * @param url The target URL.
     * @param mimetype The mime type of content.
     * @param content The content to save.
     * @exception HTTPException (FIXME will throw an RuntimeException)
     */

    public HTTPReport put(String url
			  , String mimetype
			  , String content) {
	try {
	    HttpManager m  = getManager();
	    Request     rq = m.createRequest();
	    rq.setURL(new URL(url));
	    rq.setMethod("PUT");
	    rq.setContentLength(content.length());
	    rq.setContentType(new MimeType(mimetype));
	    rq.setOutputStream(new StringBufferInputStream(content));
	    // Execute the request and swallow output in tmp file:
	    Reply rp = m.runRequest(rq);
	    return makeReport(rq, rp);	    
	} catch (Exception ex) {
	    error("unable to put to "+url+": "+ex.getMessage());
	}
	// Not Reached:
	return null;
    }
    

    //    public static HTTPReport post(String url
    //				  , String content
    //				  , String mimetype
    //				  , HTTPObserver observer);
    //    public static HTTPReport get(String url
    //	                         , String mimetype
    //				 , HTTPObserver observer);

    // You wouldn't do that in real life !

    public static String fileToString(String filename) 
	throws IOException
    {
	ByteArrayOutputStream bout = new ByteArrayOutputStream();
	// File                  file = new File(filename);
	// InputStream           in   = new FileInputStream(file);
	
	byte b[] = bout.toByteArray();
	bout = null;
	return new String(b, 0, 0, b.length);
    }

    public static void usage() {
	System.out.println("put url file type");
	System.out.println("post url file type");
	System.out.println("get url file");
    }

    /**
     * For testing.
     * <pre>HTTPHandler put url file type
     * <pre>HTTPHandler get url file
     * <pre>HTTPHandler post url file type
     */

    public static void main(String args[]) {
	String cmd  = null;
	String url  = null;
	String file = null;
	String type = null;
	try {
	    // Parse command line
	    for (int i = 0 ; i < args.length ; i++) {
		switch(i) {
		  case 0:
		      cmd = args[i];
		      break;
		  case 1:
		      url = args[i];
		      break;
		  case 2:
		      file = args[i];
		      break;
		  case 3:
		      type = args[i];
		      break;
		  default:
		      usage();
		} 
	    }
	    // Exec command (handler set to emit all results to "results.http":
	    HTTPHandler handler = new HTTPHandler();
	    HTTPReport  report  = null;
	    handler.initialize(null);
	    handler.hard = "results.http";
	    if ( cmd.equalsIgnoreCase("GET") ) {
		if ((file == null) || (url == null))
		    usage();
		report = handler.get(url, file);
	    } else if ( cmd.equalsIgnoreCase("PUT") ) {
		if ((file == null) || (type == null) || (url == null))
		    usage();
		report = handler.put(url, type, fileToString(file));
	    } else if ( cmd.equalsIgnoreCase("POST") ) {
		if ((file == null) || (type == null) || (url == null))
		    usage();
		report = handler.post(url, type, fileToString(file));
	    } else {
		usage();
	    }
	    // Display results:
	    if ( report != null ) {
		System.out.println("url   : "+report.url);
		System.out.println("file  : "+report.filename);
		System.out.println("type; : "+report.mimetype);
		System.out.println("length: "+report.contentlength);
		System.out.println("status: "+report.status);
	    } else {
		System.out.println("*** no report available ?");
	    }
	} catch (Throwable ex) {
	    ex.printStackTrace();
	} 
    }
}

