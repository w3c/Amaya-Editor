package amaya;
import java.awt.*;
import java.io.*;
import thotlib.*;

public class amayaInit extends Thread {
   static int thread_no = 0;

   public static void main (String arg) {
      String properties = 
           thotlib.APIRegistry.TtaGetEnvString("JAVA_PROPERTIES");
      //System.out.println("Amaya Init...");
      HTTPAccess.Initialize(properties);

      new amayaThread(thread_no++);
   }

   public static void Stop () {
      HTTPAccess.Stop();
   }
}

