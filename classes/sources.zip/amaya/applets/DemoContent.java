/*
 * This is an Applet for Amaya.
 *
 * Daniel Veillard 1997.
 */

import thotlib.*;
import amaya.*;

public class DemoContent extends thotlib.SampleAction {
    static Document doc = null;
    static private Element elems[];
    static private Element lists[];
    static private int TOC_ID_counter = 0;
    static private String actionName = "HeadingModified";
    static private int H1;
    static private int H2;
    static private int H3;
    static private int H4;
    static private int H5;
    static private int H6;

    private void Show() {
        System.out.println("elems[" + elems[0] + ", " + elems[1] + ", " +
	                   elems[2] + ", " + elems[3] + ", " +
			   elems[4] + ", " + elems[5] + ", " +
			   elems[6] + ", " + elems[7] + "]");
        System.out.println("lists[" + lists[0] + ", " + lists[1] + ", " +
	                   lists[2] + ", " + lists[3] + ", " +
			   lists[4] + ", " + lists[5] + ", " +
			   lists[6] + ", " + lists[7] + "]");
    }

    private void AddHeader(int level, StringBuffer content, String id) {
        int i;
	int upper_level = 0;
	int nb_level = 0;
	Element text;
	Element anchor;
	Element para;
	Attribute bullet;

// System.out.println("AddHeader(" + level + ", " + content + ")");

	// Search the upper_level i.e. ancestor of the current level
	for (i = 0;i < level;i++)
	    if (elems[i] != null) {
	        upper_level = i;
		nb_level++;
	    }

// System.out.println("upper_level : " + upper_level);

	// Clean everything lower
	for (i = level + 1;i <= 6;i++) lists[i] = null;
	for (i = level + 1;i <= 6;i++) elems[i] = null;

	if (lists[upper_level] == null) {
	    /*
	     * We are adding a new subtree in the TOC tree.
	     */
	    int j;
	    Element subtree;

            // Search for the ancestor of the upper level
	    for (j = upper_level - 1;j >= 0;j--)
	        if (lists[j] != null) break;
	    if (j < 0) j = 0;


	    subtree = lists[j].LastChild();
	    if (subtree == null) {

// System.out.println("Creating new tree at level " + j);

		// Create and add a list item at the ancestor level
		subtree = HTMLElement.Create(doc, "LI");
		lists[j].InsertChild(subtree, false);
	    }

	    // Create a new list, child of the list item
	    lists[upper_level] = HTMLElement.Create(doc, "UL");
	    subtree.InsertChild(lists[upper_level], false);
	}

// System.out.println("Creating and linking new child");

	// Create and link a new list item
	elems[level] = HTMLElement.Create(doc, "LI");
	lists[upper_level].InsertChild(elems[level], false);

	// Set up the bullet type needed.
	bullet = new Attribute(doc, APIHtml.HTML_ATTR_IntItemStyle);
	switch (nb_level % 3) {
	    case 1 : 
	        bullet.SetValue(doc, APIHtml.HTML_ATTR_IntItemStyle_VAL_disc);
		break;
	    case 2 : 
	        bullet.SetValue(doc, APIHtml.HTML_ATTR_IntItemStyle_VAL_circle);
		break;
	    case 0 : 
	        bullet.SetValue(doc, APIHtml.HTML_ATTR_IntItemStyle_VAL_square);
		break;
	}
	bullet.Attach(elems[level]);

// System.out.println("Adding content of new element");

	// Add a pseudo-paragraph to contain the anchor.
	para = new Element(doc, APIHtml.HTML_EL_Pseudo_paragraph);
	if (para != null) {
	    elems[level].InsertChild(para, true);

	    // Add an anchor and fill the new text element
	    anchor = HTMLElement.Create(doc, "A");
	    if (anchor != null) {
		// link the anchor
		para.InsertChild(anchor, true);

		// Add the Href attribute
		Attribute href = new Attribute(doc, APIHtml.HTML_ATTR_HREF_);
		href.SetValue(doc, "#" + id);
		href.Attach(anchor);

		// Add a pseudo class link
		Attribute link = new Attribute(doc, APIHtml.HTML_ATTR_PseudoClass);
		link.SetValue(doc, "link");
		link.Attach(anchor);

		// add and fill the text element
		text = new Element(doc, APIHtml.HTML_EL_TEXT_UNIT);
		if (text != null) {
		    anchor.InsertChild(text, true);
		    text.SetTextContent(content.toString());
		}
	    }
	}

    }

    /*
     * Returns an ID string associated to a target element,
     * if not found, create a new (unique !) one.
     */
    public String getId(Element el) {
        Attribute attr = Attribute.GetAttribute(el, APIHtml.HTML_ATTR_ID);
	if (attr == null) {
            // Create the ID attribute.
	    attr = new Attribute(doc, APIHtml.HTML_ATTR_ID);
	    attr.Attach(el);
	}
	String id = attr.GetString();
	if ((id == null) || (id.compareTo("") == 0)) {
	    TOC_ID_counter++;
	    id = "toc" + TOC_ID_counter;

	    // Check whether this string is already in use in the document

	    // Set up the new, unique value.
	    attr.SetValue(id);
	}

// System.out.println("getId(" + el + ") = " + id);

        return(id);
    }

    public int rebuildTOC(int document) {
        long elem;
	StringBuffer content;
	String attr_val;
	Attribute attr;
	int i;

	doc = new Document(document);
	elems = new Element[8];
	lists = new Element[8];
	for (i = 0; i < 8; i++) elems[i] = null;
	for (i = 0; i < 8; i++) lists[i] = null;

// System.out.println("Rebuilding Table of Content");

	Element current = doc.Root();
	Element toc = null;
	Element old_toc = null;

	/*
	 * Search in the whole document for an element having a Class
	 * attribute with the value "TableOfContent"
	 */
        do {
// System.out.println("Searching CLASS");
	    attr = Attribute.SearchAttribute(current, 
	                  APIHtml.HTML_ATTR_Class, Attribute.SearchForward);

	    if (attr == null) break;
            attr_val = attr.GetString();
	    if ((attr_val != null) &&
	        (attr_val.compareTo("TableOfContent") == 0)) break;
// System.out.println("CLASS=" + attr_val);
	} while (attr != null);

	/*
	 * Depending wether the old TOC was found, ask the user for the
	 * location of the new TOC or save the old one for removal.
	 */
        if (attr == null) {
	    thotlib.APIInterface.TtaSetStatus(doc.DocNo(), 1,
		      "Give the insertion point for the Table of Content", "");
	    current = Element.AskUserClick();

	    Element parent = current.Parent();
	    while (parent != null) {
		int type = parent.TypeNo();

		if (type == APIHtml.HTML_EL_BODY) break;
		current = parent;
		parent = current.Parent();
	    }
	} else {
	    old_toc = current;
	}

        /*
	 * Stop displaying while modifying the document.
	 */
	doc.SetDisplayMode(Document.DeferredDisplay);

	/*
	 * Create the base element for the table of content.
	 */
        lists[0] = toc = HTMLElement.Create(doc, "UL");
	elems[0] = current;
	current.InsertSibling(toc, true);

	/*
	 * browse the document tree looking for Headings
	 */
	while (current != null) {
	    int type  = current.TypeNo();
	    if (type == APIHtml.HTML_EL_H1) {
		String id = getId(current);
	        AddHeader(1, current.TextContent(), id);
	    } else if (type == APIHtml.HTML_EL_H2) {
		String id = getId(current);
	        AddHeader(2, current.TextContent(), id);
	    } else if (type == APIHtml.HTML_EL_H3) {
		String id = getId(current);
	        AddHeader(3, current.TextContent(), id);
	    } else if (type == APIHtml.HTML_EL_H4) {
		String id = getId(current);
	        AddHeader(4, current.TextContent(), id);
	    } else if (type == APIHtml.HTML_EL_H5) {
		String id = getId(current);
	        AddHeader(5, current.TextContent(), id);
	    } else if (type == APIHtml.HTML_EL_H6) {
		String id = getId(current);
	        AddHeader(6, current.TextContent(), id);
	    }
	    current = current.NextSibling();
	}

	/*
	 * Add the TableOfContent class name to the toc
	 */
	attr = new Attribute(doc, APIHtml.HTML_ATTR_Class);
	if (attr != null) {
	    attr.Attach(toc);
	    attr.SetValue(toc, "TableOfContent");
	}

	/*
	 * Remove the olf table of content.
	 */
	if (old_toc != null)
	    old_toc.DeleteTree();
	
        /*
	 * Reenable display.
	 */
	doc.SetDisplayMode(Document.DisplayImmediately);
	doc.SetModified(true);

	return(0);
    }

    /*
     * These are the callbacks when one of the elements has been 
     * modified.
     */
    public int callbackElement(int event, int document, long element,
                                     long elementType, int position) {
	if (document == doc.DocNo())
	    rebuildTOC(document);
	return(-1);
    }
    public int callbackTarget(int event, int document, long element,
                              long target, int targetdocument) {
	if (document == doc.DocNo())
	    rebuildTOC(document);
	return(-1);
    }
    public int callbackValue(int event, int document, long element,
                             long target, int value)  {
	if (document == doc.DocNo())
	    rebuildTOC(document);
	return(-1);
    }

    /*
     * This is the callback when the document is closed.
     */
    public int callbackDialog(int event, int document, int view) {
	if (document == doc.DocNo()) {
	    System.out.println("Unregistering action \"" + actionName + "\"");
	    unregister(actionName);
	}
	return(-1);
    }

    /*
     * Register the Events associated to the modification of
     * one kind of element.
     */
    public void HandleModification(int elem) {
        Extra.AddEditorActionEvent(actionName, APIAppAction.TteElemNew,
	                           elem, false);
        Extra.AddEditorActionEvent(actionName, APIAppAction.TteElemDelete,
	                           elem, false);
        Extra.AddEditorActionEvent(actionName, APIAppAction.TteElemMove,
	                           elem, false);
        Extra.AddEditorActionEvent(actionName, APIAppAction.TteElemChange,
	                           elem, false);
        Extra.AddEditorActionEvent(actionName, APIAppAction.TteElemTextModify,
	                           elem, false);
        Extra.AddEditorActionEvent(actionName, APIAppAction.TteElemPaste,
	                           elem, false);
    }

    public static int main(int document, String args[]) {
	DemoContent new_action = new DemoContent();
	boolean uninstall = false;

// System.out.println("DemoContent() started");

        if (args.length > 0) {
	    if ((args[0].compareTo("uninstall") == 0) ||
	        (args[0].compareTo("desinstall") == 0) ||
		(args[0].compareTo("stop") == 0) ||
		(args[0].compareTo("halt") == 0)) {
		uninstall = true;
	        if (args.length > 1) {
		    actionName = args[1];
		}
	    } else
		actionName = args[0];
	}
	if (uninstall) {
//	    System.out.println("Unregistering action \"" + actionName + "\"");
	    new_action.unregister(actionName);
	} else {
	    new_action.rebuildTOC(document);
	    System.out.println("Registering action \"" + actionName + "\"");
	    new_action.register(actionName);
            Extra.AddEditorActionEvent(actionName,
	                APIAppAction.TteDocClose, 0, false);
	    new_action.HandleModification(APIHtml.HTML_EL_H1);
	    new_action.HandleModification(APIHtml.HTML_EL_H2);
	    new_action.HandleModification(APIHtml.HTML_EL_H3);
	    new_action.HandleModification(APIHtml.HTML_EL_H4);
	    new_action.HandleModification(APIHtml.HTML_EL_H5);
	    new_action.HandleModification(APIHtml.HTML_EL_H6);
	}
	return(0);
    }
}
