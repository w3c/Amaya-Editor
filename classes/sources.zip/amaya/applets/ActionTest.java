/*
 * This is an Applet for Amaya.
 *
 */

import thotlib.*;
import amaya.*;

class ActionTest extends thotlib.SampleAction {

    public int callbackMenu(int document, int view) {
	System.out.println("ActionTest : Handling an action");
        System.out.println("ActionTest.callbackMenu(" + document + ", " +
	                   view + ")");
	return(-1); // let the normal processing occur
    }
    public int callbackNotify(int event) {
	System.out.println("ActionTest : Handling an action");
        System.out.println("ActionTest.callbackNotify(" + event + ")");
	return(-1); // let the normal processing occur
    }
    public int callbackDialog(int event, int document, int view) {
	System.out.println("ActionTest : Handling an action");
        System.out.println("ActionTest.callbackDialog(" + event + ", " +
	                   document + ", " + view + ")");
	return(-1); // let the normal processing occur
    }
    public int callbackWindow(int event, int document, int view,
                    int verticalValue, int horizontalValue) {
	System.out.println("ActionTest : Handling an action");
        System.out.println("ActionTest.callbackWindow(" + event + ", " +
	                   document + ", " + view + ", " + 
			   verticalValue + ", " + horizontalValue + ")");
	return(-1); // let the normal processing occur
    }
    public int callbackAttribute(int document, int view, long element,
                               long attribute, long attributeType) {
	System.out.println("ActionTest : Handling an action");
        System.out.println("ActionTest.callbackAttribute(" + document + ", " +
	                   view + ", " + element + ", " + attribute + ", " +
			   attributeType + ")");
	return(-1); // let the normal processing occur
    }
    public int callbackElement(int document, int view, long element,
                               long sschema, int type,  int position) {
	/***********************************************************
	elementType &= 0xFFFFFFFFL;
	System.out.println("ActionTest : Handling an action");
        System.out.println("ActionTest.callbackElement(" + document + ", " +
	                   view + ", " + element + ", " + elementType + ", " +
			   position + ")");
        System.out.println("Blocking the standard processing");
	 ***********************************************************/
	if (type == APIHtml.HTML_EL_TEXT_UNIT) {
	    Element el = new Element(element);
	    Element parent = el.Parent();

	    parent.Select();
	}
	return(0); // let the normal processing occur
    }
    public int callbackElementType(int document, int view, long element,
                               long newsschema, int newtype,
			       long schema, int type) {
	System.out.println("ActionTest : Handling an action");
        System.out.println("ActionTest.callbackElementType(" + document + ", " +
	                   view + ", " + element + ", " + newtype + ", " +
			   type + ")");
	return(-1); // let the normal processing occur
    }
    public int callbackTarget(int document, int view, long element,
                               long target, int targetdocument) {
	System.out.println("ActionTest : Handling an action");
        System.out.println("ActionTest.callbackTarget(" + document + ", " +
	                   view + ", " + element + ", " + target + ", " +
			   targetdocument + ")");
	return(-1); // let the normal processing occur
    }
    public int callbackValue(int document, int view, long element,
                               long target, int value) {
	System.out.println("ActionTest : Handling an action");
        System.out.println("ActionTest.callbackValue(" + document + ", " +
	                   view + ", " + element + ", " + target + ", " +
			   value + ")");
	return(-1); // let the normal processing occur
    }
    public int callbackPresentation(int document, int view, long element,
                               long pRule, int pRuleType) {
	System.out.println("ActionTest : Handling an action");
        System.out.println("ActionTest.callbackPresentation(" + document + ", " +
	                   view + ", " + element + ", " + pRule + ", " +
			   pRuleType + ")");
	return(-1); // let the normal processing occur
    }

    static public int main(String[] args) {
	if ((args != null) && (args.length > 0)) {
	    // Install on the ActionName given in argument.
	    ActionTest new_action = new ActionTest();
	    new_action.register(args[0]);
	} else {
	    ActionTest new_action = new ActionTest();
	    new_action.registerMenu("New");
	    new_action.register("NewAmayaClick");
	    Extra.AddEditorActionEvent("NewAmayaClick",
	           APIAppAction.TteElemSelect, 
		   APIHtml.HTML_EL_Anchor, true);
	    Extra.AddEditorActionEvent("NewAmayaClick",
	           APIAppAction.TteElemSelect, 
		   APIHtml.HTML_EL_TEXT_UNIT, true);
	}
	return(0);
    }
}

