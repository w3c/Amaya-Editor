/*
 * This is an Applet for Amaya.
 *    It install itself as an action when clicking on a text element,
 *    selects the whole element (or it's parent). If the parent is an
 *    anchor it displays the URL in the status bar.
 */

import thotlib.*;
import amaya.*;

class DemoAction extends thotlib.SampleAction {

    // Needed to set all this static in order to restore
    // things when stopping the demo :-(
    static int last_document = 0;
    static int last_color = 0;
    static long last_element = 0;
    static long last_prule = 0;

    static public void restore_color() {
	if (last_element != 0) {
	    if (last_color == 0)
		APIPresentation.TtaRemovePRule(last_element, last_prule,
					       last_document);
	    else
		APIPresentation.TtaSetPRuleValue(last_element, last_prule,
					       last_color, last_document);
	}
        last_element = 0;
    }

    public int callbackElement(int event, int document, long element,
                               long sschema, int elementType, int position) {
	if (elementType == APIHtml.HTML_EL_TEXT_UNIT) {
	    int type;

	    // If the user clicked on a text unit, select the parent.
	    Element el = new Element(element);
	    Element parent = el.Parent();

	    // parent.Select();
	    // Restore the color of the previously selected element
            restore_color();

	    long prule_val = APIPresentation.TtaGetPRule(parent.Value(), 
					        APIPresentation.PRForeground);
	    if (prule_val == 0) {
		prule_val = APIPresentation.TtaNewPRule(
		                APIPresentation.PRForeground,1,document);
		APIPresentation.TtaAttachPRule(parent.Value(),prule_val,document);
		last_color = 0;
	    } else {
	        last_color = APIPresentation.TtaGetPRuleValue(prule_val);
	    }
	    last_prule = prule_val;
	    APIPresentation.TtaSetPRuleValue(parent.Value(), prule_val, 12,
	                        document);
	    last_element = parent.Value();
            last_document = document;

	    type = parent.Type().GetType();
	    if (type == APIHtml.HTML_EL_Anchor) {
		Attribute src = thotlib.Attribute.GetAttribute(parent,
		            APIHtml.HTML_ATTR_HREF_);
	        if (src != null) {
		    String href = src.GetString();
		    if (href != null) 
			thotlib.APIInterface.TtaSetStatus(document, 1, href, "");
		}
	    }
	}
	return(0); // block the normal processing
    }

    static public int main(String[] args) {
	DemoAction new_action = new DemoAction();
	String actionName = "NewAmayaClick";
	boolean uninstall = false;

        if (args.length > 0) {
	    if ((args[0].compareTo("uninstall") == 0) ||
	        (args[0].compareTo("desinstall") == 0) ||
		(args[0].compareTo("stop") == 0) ||
		(args[0].compareTo("halt") == 0)) {
		uninstall = true;
	        if (args.length > 1) {
		    actionName = args[1];
		}
	    } else
		actionName = args[0];
	}
	if (uninstall) {
            restore_color();
	    System.out.println("Unregistering action \"" + actionName + "\"");
	    new_action.unregister(actionName);
	} else {
	    System.out.println("Registering action \"" + actionName + "\"");
	    new_action.register(actionName);
	    Extra.AddEditorActionEvent(actionName, APIAppAction.TteElemSelect, 
		   APIHtml.HTML_EL_TEXT_UNIT, true);
	}
	return(0);
    }
}

