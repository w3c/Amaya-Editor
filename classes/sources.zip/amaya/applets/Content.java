/*
 * This is an Applet for Amaya.
 *
 * It prints out the text of the first H1 of the Document every 10 second
 * to give a fancy demo of scripting capabilities.
 */

import thotlib.*;
import amaya.*;

public class Content {
    public static int main(int document) {
        long elem;
	StringBuffer content;

	Document doc = new Document(document);
	Element current = doc.Root();
	ElementType elType = new ElementType(current);
        elType.SetValue((long) APIHtml.HTML_EL_H1);

	current = doc.Root();
	
	elem = APITree.TtaSearchTypedElement(elType.Value(),
			 APITree.SearchInTree, current.Value());
	if (elem != 0) {
	    current = new Element(elem);
	    content = current.TextContent();
	    System.out.println("Content of first H1 :");
	    System.out.println(content);
	}
	return(0);
    }
}
