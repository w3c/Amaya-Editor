// ToolsLister.java
// $Id: ToolsLister.java,v 1.1 1998/03/13 16:15:48 ylafon Exp $
// (c) COPYRIGHT MIT and INRIA, 1998.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.cvs;

import java.util.*;
import java.io.*;

import org.w3c.tools.resources.*;

public class ToolsLister extends FramedResource {
    
    public void initialize(Object values[]) {
	super.initialize(values);
	try {
	    registerFrameIfNone("org.w3c.jigsaw.cvs.ToolsListerFrame",
				"toolslister-frame");
	} catch (Exception ex) {
	    ex.printStackTrace();
	}
    }
}
