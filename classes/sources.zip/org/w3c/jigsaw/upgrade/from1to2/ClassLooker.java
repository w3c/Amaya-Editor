// ClassLooker.java
// $Id: ClassLooker.java,v 1.3 1997/07/30 14:01:35 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.upgrade.from1to2;

public class ClassLooker {

    public static boolean isSubclass(String clsname, String superclsname) 
	throws ClassNotFoundException
    {
	Class cls      = Class.forName(clsname);
	Class supercls = Class.forName(superclsname);
	while ((cls != null) && (cls != supercls)) 
	    cls = cls.getSuperclass();
	return (cls != null);
    }

}
