// UpgradeAttributeHolderAttribute.java
// $Id: UpgradeAttributeHolderAttribute.java,v 1.3 1997/07/30 14:02:11 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.upgrade.from1to2;

import java.io.*;

public class UpgradeAttributeHolderAttribute extends UpgradeAttribute {

    protected void pickle(DataOutputStream out) 
	throws IOException
    {
	byte bits[] = (byte[]) val;
	out.writeShort(bits.length);
	out.write(bits);
    }

    UpgradeAttributeHolderAttribute(w3c.tools.store.Attribute attr
				    , Object val) {
	super(attr, val);
    }
}


