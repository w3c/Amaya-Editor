// UpgradeAttribute.java
// $Id: UpgradeAttribute.java,v 1.3 1997/07/30 14:02:07 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.upgrade.from1to2;

import java.io.*;

public class UpgradeAttribute {
    w3c.tools.store.Attribute attr = null;
    Object    val  = null;

    protected void pickle(DataOutputStream out) 
	throws IOException
    {
	out.writeShort(attr.getPickleLength(val));
	attr.pickle(out, val);
    }

    UpgradeAttribute(w3c.tools.store.Attribute attr, Object val) {
	this.attr = attr;
	this.val  = val;
    }
}


