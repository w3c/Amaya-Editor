// ResourceUpgraderException.java
// $Id: ResourceUpgraderException.java,v 1.2 1997/07/30 14:01:58 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.upgrade.from1to2;

public class ResourceUpgraderException extends Exception {

    public ResourceUpgraderException(String msg) {
	super(msg);
    }

}


