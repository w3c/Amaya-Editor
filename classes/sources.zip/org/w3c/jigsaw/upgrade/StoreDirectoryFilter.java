// StoreDirectoryFilter.java
// $Id: StoreDirectoryFilter.java,v 1.2 1997/01/15 14:58:18 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.upgrade;

import java.io.*;

/**
 * Filters files in a store directory that contains only simple resource
 * stores.
 */

public class StoreDirectoryFilter implements FilenameFilter {

    public boolean accept(File dir, String name) {
	return (! name.endsWith(".bak")) && ( ! name.equals("state"));
    }

}
