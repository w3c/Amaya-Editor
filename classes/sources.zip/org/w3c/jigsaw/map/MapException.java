// MapException.java
// $Id: MapException.java,v 1.4 1998/02/19 10:48:17 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.map;

class MapException extends RuntimeException {
    public MapException(String msg)
    {
	super(msg);
    }
}

