// HeaderFilter.java
// $Id: HeaderFilter.java,v 1.4 1997/01/17 09:49:44 abaird Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.contrib;

import java.net.*;

import w3c.tools.store.*;
import w3c.www.http.*;
import w3c.jigsaw.http.*;
import w3c.jigsaw.resources.*;

/**
 * Enforces a specific header value on all replies.
 * Usefull for testing.
 */

public class HeaderFilter extends ResourceFilter {
    /**
     * Attribute index - The header name to add to replies.
     */
    protected static int ATTR_HEADER_NAME = -1;
    /**
     * Attribute index - The header value.
     */
    protected static int ATTR_HEADER_VALUE = -1;
    /**
     * Attribute index - SHould we use no-cache on that header.
     */
    protected static int ATTR_NOCACHE = -1;
    /**
     * Attribute index - Should we use connection on that header.
     */
    protected static int ATTR_CONNECTION = -1;

    static {
	Class c = null;
	Attribute a = null;
	try {
	    c = Class.forName("w3c.jigsaw.contrib.HeaderFilter");
	} catch (Exception ex) {
	    ex.printStackTrace();
	    System.exit(1);
	}
	// Register the header name attribute:
	a = new StringAttribute("header-name"
				, null
				, Attribute.EDITABLE);
	ATTR_HEADER_NAME = AttributeRegistry.registerAttribute(c, a);
	// Register the header value attribute.
	a = new StringAttribute("header-value"
				, null
				, Attribute.EDITABLE);
	ATTR_HEADER_VALUE = AttributeRegistry.registerAttribute(c, a);
	// Register the nocache attribute.
	a = new BooleanAttribute("no-cache"
				 , Boolean.FALSE
				 , Attribute.EDITABLE);
	ATTR_NOCACHE = AttributeRegistry.registerAttribute(c, a);
	// Register the connection attribute.
	a = new BooleanAttribute("connection"
				 , Boolean.FALSE
				 , Attribute.EDITABLE);
	ATTR_CONNECTION = AttributeRegistry.registerAttribute(c, a);
    }

	
    /**
     * Get the header to set, if any.
     * @return A String encoded header name, or <strong>null</strong>.
     */

    public String getHeaderName() {
	String value = getString(ATTR_HEADER_NAME, null);
	if ( value != null )
	    return value.toLowerCase();
	return null;
    }

    /**
     * Get the header value to set, if any.
     * @return A String encoded value for the header to set, or <strong>
     * null</strong>.
     */
    
    public String getHeaderValue() {
	return getString(ATTR_HEADER_VALUE, null);
    }

    /**
     * Should we add this header's name to the <code>no-cache</code> 
     * directive.
     * @return A boolean.
     */

    public boolean checkNoCache() {
	return getBoolean(ATTR_NOCACHE, false);
    }

    /**
     * Should we add this header to the connection header.
     * @return A boolean.
     */

    public boolean checkConnection() {
	return getBoolean(ATTR_CONNECTION, false);
    }

    public Reply ingoingFilter(Request request) {
	return null;
    }

    /**
     * The outgoing filter decorates the reply appropriately.
     * @param request The original request.
     * @param reply The originial reply.
     * @return Always <strong>null</strong>.
     */

    public Reply outgoingFilter(Request request, Reply reply) {
	String hname = getHeaderName();
	if ( hname != null ) {
	    String hvalue = getHeaderValue();
	    if ( hvalue == null ) {
		reply.removeHeader(hname);
	    } else {
		reply.setValue(hname, hvalue);
	    }
	    if ( checkNoCache() )
		reply.addNoCache(hname);
	    if ( checkConnection() )
		reply.addConnection(hname);
	}
	return null;
    }
}


   
     
