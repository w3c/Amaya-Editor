// SampleCommand.java
// $Id: SampleCommand.java,v 1.2 1998/02/24 13:04:12 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.ssi.commands ;

import java.util.*;

import org.w3c.www.http.HTTP ;
import org.w3c.util.* ;
import org.w3c.tools.resources.* ;
import org.w3c.jigsaw.http.*;
import org.w3c.jigsaw.ssi.*;

public class SampleCommand extends BasicCommand {
    protected static final String NAME = "params";

    public Reply execute(SSIFrame ssiframe,
			 Request request,
			 ArrayDictionary parameters,
			 Dictionary variables)
    {
	Reply reply = ssiframe
	    .createCommandReply(request,HTTP.OK) ;
	StringBuffer sb = new StringBuffer();
	sb.append("<ul>");
	for(int i=0;i<parameters.capacity() && parameters.keyAt(i) != null;i++) 
	    sb.append("<li>"+parameters.keyAt(i)+" = \""+
		      parameters.elementAt(i)+"\"</li>");
	sb.append("</ul>");
	reply.setContent(sb.toString());

	handleSimpleIMS(request,reply) ;
	return reply ;
    }

    public String getName()
    {
	return NAME;
    }

  public String getValue(Dictionary variables, 
			 String variable, 
			 Request request) {
    return "null";
  }

}
