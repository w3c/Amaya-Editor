// PasswordEditor.java
// $Id: PasswordEditor.java,v 1.1 1998/02/13 15:28:28 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.resources;

import java.util.*;

import org.w3c.tools.resources.*;

public class PasswordEditor extends FramedResource {

  public void initialize(Object values[]) {
    super.initialize(values);
    try {
      Class passwd_frame = 
	Class.forName("org.w3c.jigsaw.resources.PasswordEditorFrame");
      ResourceFrame frame = getFrame(passwd_frame);
      if (frame == null) {
	Hashtable defs = new Hashtable(3);
	defs.put("identifier" , "passwd-frame");
	registerFrame( new PasswordEditorFrame() , defs );
      }
    } catch (ClassNotFoundException ex) {
      throw new RuntimeException("can't register PasswordEditorFrame : "+
				 ex.getMessage());
    }
  }

}
