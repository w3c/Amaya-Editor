// PasswordEditor.java
// $Id: PasswordEditor.java,v 1.2 1998/02/26 13:18:03 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.resources;

import java.util.*;

import org.w3c.tools.resources.*;

public class PasswordEditor extends FramedResource {

  public void initialize(Object values[]) {
    super.initialize(values);
    try {
      registerFrameIfNone("org.w3c.jigsaw.resources.PasswordEditorFrame",
			  "passwd-frame");
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

}
