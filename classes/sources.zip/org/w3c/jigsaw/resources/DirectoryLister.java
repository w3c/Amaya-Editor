// DirectoryLister.java
// $Id: DirectoryLister.java,v 1.6 1998/02/26 13:17:44 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.resources ;

import java.util.*;
import java.io.*;

import org.w3c.tools.resources.*;

public class DirectoryLister extends FramedResource {

  
  public void initialize(Object values[]) {
    super.initialize(values);
    try {
      registerFrameIfNone("org.w3c.jigsaw.resources.DirectoryListerFrame",
			  "lister-frame");
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

}
