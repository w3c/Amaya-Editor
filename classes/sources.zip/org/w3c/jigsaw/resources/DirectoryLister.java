// DirectoryLister.java
// $Id: DirectoryLister.java,v 1.5 1998/02/13 15:28:07 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.resources ;

import java.util.*;
import java.io.*;

import org.w3c.tools.resources.*;

public class DirectoryLister extends FramedResource {

  
  public void initialize(Object values[]) {
    super.initialize(values);
    try {
      Class lister_frame = 
	Class.forName("org.w3c.jigsaw.resources.DirectoryListerFrame");
      ResourceFrame frame = getFrame(lister_frame);
      if (frame == null) {
	Hashtable defs = new Hashtable(3);
	defs.put("identifier" , "lister-frame");
	registerFrame( new DirectoryListerFrame() , defs );
      }
    } catch (ClassNotFoundException ex) {
      throw new RuntimeException("can't register DirectoryListerFrame : "+
				 ex.getMessage());
    }
  }
}
