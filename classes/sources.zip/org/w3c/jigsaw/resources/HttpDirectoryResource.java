// HttpDirectoryResource.java
// $Id: HttpDirectoryResource.java,v 1.1 1998/02/26 13:17:47 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.resources ;

import java.util.*;
import java.io.*;

public class HttpDirectoryResource extends DirectoryResource {

  public void initialize(Object values[]) {
    super.initialize(values);
    try {
      registerFrameIfNone("org.w3c.jigsaw.frames.HTTPFrame",
			  "http-frame");
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

}
