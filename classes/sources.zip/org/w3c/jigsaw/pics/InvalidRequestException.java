// InvalidRequestException.java
// $Id: InvalidRequestException.java,v 1.1 1997/05/21 12:55:04 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package w3c.jigsaw.pics ;

public class InvalidRequestException extends Exception {
  public InvalidRequestException (String msg) {
    super (msg) ;
  }
}
