// URLDecoderException.java
// $Id: URLDecoderException.java,v 1.2 1998/01/22 13:58:38 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.forms ;

public class URLDecoderException extends Exception {
    URLDecoderException (String msg) {
	super (msg) ;
    }
}

