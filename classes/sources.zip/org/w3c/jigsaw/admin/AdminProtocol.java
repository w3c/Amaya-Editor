// AdminProtocol.java
// $Id: AdminProtocol.java,v 1.4 1998/01/23 10:07:46 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.admin;

public interface AdminProtocol {

    public static final byte WIRED_PLAIN    = (byte) 1;
    public static final byte WIRED_FRAMED  =  (byte) 3;
}
