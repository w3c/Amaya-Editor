// AdminProtocolException.java
// $Id: AdminProtocolException.java,v 1.3 1998/01/22 13:47:34 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.admin;

public class AdminProtocolException extends Exception {
    
    AdminProtocolException(String msg) {
	super(msg);
    }

}
