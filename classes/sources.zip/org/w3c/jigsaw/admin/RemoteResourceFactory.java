// RemoteResourceFactory.java 
// $Id: RemoteResourceFactory.java,v 1.5 1998/01/22 13:49:13 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.admin;

import java.net.URL;

public class RemoteResourceFactory {
    AdminContext admin = null;

    public RemoteResource createRemoteResource(URL parent
					       , String identifier
					       , String clsnames[]) {
	return new PlainRemoteResource(admin, parent, identifier, clsnames);
    }

    public RemoteResource createRemoteResource(URL url, String classes[]) {
	return new PlainRemoteResource(admin, null, null, url, classes);
    }

    RemoteResourceFactory(AdminContext admin) {
	this.admin = admin;
    }

}
