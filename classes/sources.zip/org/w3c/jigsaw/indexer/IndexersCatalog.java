// IndexersCatalog.java
// $Id: IndexersCatalog.java,v 1.2 1997/07/30 14:00:15 ylafon Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html


package w3c.jigsaw.indexer;

import java.util.*;
import java.io.*;

import w3c.tools.store.*;
import w3c.jigsaw.resources.*;

public class IndexersCatalog extends SampleContainer { 
    private Hashtable defs = null;

    protected Hashtable getDefaultAttributes() {
	return defs;
    }

    public IndexersCatalog(ResourceContext context) {
	super("indexers"
	      , context.getServer().getResourceStoreManager()
	      , new File(context.getServer().getIndexerDirectory(), "idx.db"));
	this.defs       = new Hashtable(3);
	this.defs.put("context", context);
    }


   
}
