// RealmsCatalog.java
// $Id: RealmsCatalog.java,v 1.11 1998/02/26 10:16:50 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.auth;

import java.util.*;
import java.io.*;

import org.w3c.tools.resources.*;
import org.w3c.jigsaw.http.*;

public class RealmsCatalog extends ExternalContainer {

  protected String rep = null;

  /**
   * Load the given realm and return the AuthRealm instance.
   * @param name The realm identifier.
   */

  public synchronized ResourceReference loadRealm(String name) {
    return lookup(name);
  }

  /**
   * Enumerate the list of available realms.
   */

  public synchronized Enumeration enumerateRealmNames() {
    return enumerateResourceIdentifiers() ;
  }

  /**
   * register the given new realm.
   * @param realm The new realm to register.
   */

  public synchronized void registerRealm(AuthRealm realm) {
    addResource(realm, null) ;
  }
   
  public void registerResource(String name,
			       Resource resource,
			       Hashtable defs) 
  {
    if ( resource instanceof AuthRealm)
      registerRealm(AuthRealm.makeRealm( new ResourceContext(getContext()),
					 name ));
  }
    
  /**
   * Unregister the given realm from the catalog.
   * @param name The name of the catalog.
   */

  public synchronized void unregisterRealm(String name) 
    throws MultipleLockException
  {
    delete(name);
  }

  /**
   * Save the catalog back to disk.
   */

  public synchronized void save() {

  }

  public File getRepository(ResourceContext context) {
    return new File(context.getServer().getAuthDirectory(), rep);
  }

  public RealmsCatalog(ResourceContext context) {
    this(context, "realms.db");
  }

  public RealmsCatalog(ResourceContext context, String rep) {
    super();
    this.rep = (rep.endsWith(".db")) ? rep : rep + ".db";
    this.transientFlag = true;
    Hashtable h        = new Hashtable(3);
    h.put("identifier", "realms");
    h.put("context", context);
    initialize(h);
    context.setResourceReference( new DummyResourceReference(this));
  }
}
