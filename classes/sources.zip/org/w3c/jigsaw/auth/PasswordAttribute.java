// PasswordAttribute.java
// $Id: PasswordAttribute.java,v 1.5 1998/01/22 13:50:37 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.auth ;

import org.w3c.tools.resources.*;

public class PasswordAttribute extends StringAttribute {

    public PasswordAttribute(String name, String password, int flags) {
	super(name, password, flags);
	this.type = "java.lang.String";
    }

}
