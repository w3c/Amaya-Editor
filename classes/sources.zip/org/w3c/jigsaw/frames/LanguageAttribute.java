// LanguageAttribute.java
// $Id: LanguageAttribute.java,v 1.1 1998/01/22 13:59:14 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.frames ;

import org.w3c.tools.resources.*;

public class LanguageAttribute extends StringAttribute {

    public LanguageAttribute(String name, String def, int flags) {
	super(name, def, flags) ;
	this.type = "java.lang.String";
    }

}
