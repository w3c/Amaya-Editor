// RedirecterFrame.java
// $Id: RedirecterFrame.java,v 1.1 1998/02/13 09:56:43 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.frames;

import java.util.*;
import java.io.* ;
import java.net.*;

import org.w3c.tools.resources.*;
import org.w3c.jigsaw.http.*;
import org.w3c.www.http.*;

import org.w3c.tools.resources.ProtocolException;
import org.w3c.tools.resources.NotAProtocolException;

/**
 * Perform an internal redirect.
 */
public class RedirecterFrame extends HTTPFrame {
    /**
   * Attributes index - The index for the target attribute.
   */
  protected static int ATTR_TARGET = -1 ;

  static {
    Attribute a   = null ;
    Class     cls = null ;
    // Get a pointer to our class:
    try {
      cls = Class.forName("org.w3c.jigsaw.frames.RedirecterFrame") ;
    } catch (Exception ex) {
      ex.printStackTrace() ;
      System.exit(1) ;
    }
    a = new StringAttribute("target"
			    , null
			    , Attribute.EDITABLE);
    ATTR_TARGET = AttributeRegistry.registerAttribute(cls, a) ;
  }

  protected String getTarget() {
    return (String) getValue(ATTR_TARGET, null);
  }

  public ReplyInterface perform(RequestInterface req) 
    throws ProtocolException, NotAProtocolException
  {
    Reply        reply  = (Reply) performFrames(req);
    if (reply != null) 
      return reply;
    Request request = (Request) req;
    httpd        server = (httpd) getServer();
    request.setReferer(getURLPath());
    try {
      request.setURL( new URL(server.getURL(), getTarget()));
    } catch (MalformedURLException ex) {
      Reply error = request.makeReply(HTTP.INTERNAL_SERVER_ERROR);
      error.setContent("<html><head><title>Server Error</title>"+
		       "</head><body><h1>Server misconfigured</h1>"+
		       "<p>The resource <b>"+getIdentifier()+"</b>"+
		       "has an invalid target attribute : <p><b>"+
		       getTarget()+"</b></body></html>");      
      throw new HTTPException (error);
    }
    return server.perform(request);
  }
}
