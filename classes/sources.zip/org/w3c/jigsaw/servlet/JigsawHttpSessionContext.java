// JigsawHttpSessionContext.java
// $Id: JigsawHttpSessionContext.java,v 1.1 1998/05/14 15:04:32 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1998.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.*;
import java.util.*;

/**
 * @version $Revision: 1.1 $
 * @author  Beno�t Mah� (bmahe@w3.org)
 */
public class JigsawHttpSessionContext implements HttpSessionContext {
    
    private Hashtable sessions;
    private int sessionNb = 0;

    public Enumeration getIds()
    {
        return sessions.keys();
    }

    public  HttpSession getSession(String sessionId) {
	return (HttpSession)sessions.get(sessionId);
    }

    public synchronized String addSession(JigsawHttpSession session) {
	String id = getNewSessionId();
	sessions.put(id, session);
	return id;
    }

    public void removeSession(String id) {
	sessions.remove(id);
    }

    String getNewSessionId() {
	return String.valueOf(new Date().hashCode())+"-"+(sessionNb++);
    }

    public JigsawHttpSessionContext() {
	sessions  = new Hashtable(3);
    }

}
