// JigsawHttpSession.java
// $Id: JigsawHttpSession.java,v 1.3 1998/05/14 16:18:52 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1998.
// Please first read the full copyright statement in file COPYRIGHT.html
 
package org.w3c.jigsaw.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.*;
import java.util.*;

/**
 * @version $Revision: 1.3 $
 * @author  Beno�t Mah� (bmahe@w3.org)
 */
public class JigsawHttpSession implements HttpSession {

    private JigsawHttpSessionContext sc = null;

    private String id = null;

    private long creationTime     = -1;
    private long lastAccessedTime = -1;

    private boolean isValid = false;
    private boolean isNew   = false;

    private Cookie cookie = null;

    private Hashtable values = null;

    public String getId() {
	return id;
    }

    public HttpSessionContext getSessionContext() {
	return sc;
    }

    public long getCreationTime() {
	return creationTime;
    }

    public long getLastAccessedTime() {
	return lastAccessedTime;
    }

    public void setLastAccessedTime() {
	lastAccessedTime = System.currentTimeMillis();
    }

    public void invalidate() {
	isValid = false;
	sc.removeSession(id);
    }

    public Object getValue(String name) {
	if (!isValid)
            throw new IllegalStateException("Invalid session");
	return values.get(name);
    }

    public void putValue(String name, Object value)
    {
	if (!isValid)
            throw new IllegalStateException("Invalid session");
	removeValue(name);
	values.put(name, value);
	if (value instanceof HttpSessionBindingListener)
	    valueBound((HttpSessionBindingListener)value, name);
    }

    public void removeValue(String name) {
	if (!isValid)
            throw new IllegalStateException("Invalid session");
	Object value = values.get(name);
	if (value != null) {
	    values.remove(name);
	    if (value instanceof HttpSessionBindingListener)
		valueUnbound((HttpSessionBindingListener)value, name);
	}
    }

    protected void valueBound(HttpSessionBindingListener value, String name) 
    {
	value.valueBound(new HttpSessionBindingEvent(this, name));
    }

    protected void valueUnbound(HttpSessionBindingListener value, String name) 
    {
	value.valueUnbound(new HttpSessionBindingEvent(this, name));
    }
    
    public String[] getValueNames() {
	if (!isValid)
            throw new IllegalStateException("Invalid session");
	String names[] = new String[values.size()];
	Enumeration enum = values.keys();
	int i = 0;
	while (enum.hasMoreElements())
	    names[i++] = (String)enum.nextElement();
	return names;
    }

    public boolean isNew() {
	return isNew;
    }

    public void setNoMoreNew() {
	isNew = false;
    }

    public boolean isValid() {
        return isValid;
    }

    public Cookie getCookie() {
        return cookie;
    }

    public JigsawHttpSession(JigsawHttpSessionContext context, Cookie cookie) {
	this.values = new Hashtable();
	this.creationTime = System.currentTimeMillis();
	this.lastAccessedTime = creationTime;
	this.sc = context;
	this.id = context.addSession(this);
	this.cookie = cookie;
	cookie.setValue(this.id);
	isValid = true;
	isNew = true;
    }

}
