// HttpParserException.java
// $Id: HttpParserException.java,v 1.3 1998/01/22 14:28:40 bmahe Exp $$
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html


package org.w3c.www.http;

import org.w3c.www.mime.*;

public class HttpParserException extends MimeParserException {
    
    public HttpParserException(String msg) {
	super(msg);
    }

}
