// MimeType.java
// $Id: MimeTypeFormatException.java,v 1.2 1998/01/22 14:30:41 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.www.mime ;

public class MimeTypeFormatException extends Exception {

    public MimeTypeFormatException(String msg) {
	super(msg);
    }

}
