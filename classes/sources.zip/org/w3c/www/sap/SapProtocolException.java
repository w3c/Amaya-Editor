// SapProtocolException.java
// $Id: SapProtocolException.java,v 1.2 1998/01/22 14:40:49 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.www.sap;

public class SapProtocolException extends Exception {

    public SapProtocolException(String msg) {
	super(msg);
    }

}
