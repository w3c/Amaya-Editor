/*
 *  MultipleValueAccessException.java
 *
 *  Copyright 1997 Massachusetts Institute of Technology.
 *  All Rights Reserved.
 *
 *  Author: Ora Lassila
 *
 *  $Id: MultipleValueAccessException.java,v 1.2 1998/01/22 14:33:18 bmahe Exp $
 */

package org.w3c.www.pics;

public class MultipleValueAccessException extends Exception {

  public MultipleValueAccessException()
  {
    super("Rating has more than one value");
  }

}
