/*
 *  Mapper.java
 *
 *  Copyright 1997 Massachusetts Institute of Technology.
 *  All Rights Reserved.
 *
 *  Author: Ora Lassila
 *
 *  $Id: Mapper.java,v 1.2 1998/01/22 14:33:14 bmahe Exp $
 */

package org.w3c.www.pics;

public interface Mapper {

  public Object map(Object value) throws PICSParserException;

}
