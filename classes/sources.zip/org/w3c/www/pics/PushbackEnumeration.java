/*
 *  PushbackEnumeration.java
 *
 *  Copyright 1997 Massachusetts Institute of Technology.
 *  All Rights Reserved.
 *
 *  Author: Ora Lassila
 *
 *  $Id: PushbackEnumeration.java,v 1.2 1998/01/22 14:33:41 bmahe Exp $
 */

package org.w3c.www.pics;

import java.util.Enumeration;

public class PushbackEnumeration implements Enumeration {

  private Enumeration source;
  private boolean pushedBack;
  private Object next;

  public PushbackEnumeration(Enumeration source)
  {
    this.source = source;
    this.pushedBack = false;
  }

  public boolean hasMoreElements()
  {
    return pushedBack || source.hasMoreElements();
  }

  public Object nextElement()
  {
    if (pushedBack) {
      pushedBack = false;
      return next;
    }
    else return source.nextElement();
  }

  public Object peekElement()
  {
    if (!pushedBack) {
      pushedBack = true;
      next = source.nextElement();
    }
    return next;
  }

  public void push(Object element)
  {
    next = element;
    pushedBack = true;
  }

}
