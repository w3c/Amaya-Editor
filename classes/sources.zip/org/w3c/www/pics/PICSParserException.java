/*
 *  PICSParserException.java
 *
 *  Copyright 1997 Massachusetts Institute of Technology.
 *  All Rights Reserved.
 *
 *  Author: Ora Lassila
 *
 *  $Id: PICSParserException.java,v 1.2 1998/01/22 14:33:34 bmahe Exp $
 */

package org.w3c.www.pics;

import org.w3c.tools.sexpr.SExprParserException;

public class PICSParserException extends SExprParserException {

  private Exception original;

  public PICSParserException(String explanation)
  {
    super(explanation);
    this.original = null;
  }

  public PICSParserException(String explanation, Exception original)
  {
    super(explanation);
    this.original = original;
  }

  public Exception getOriginal()
  {
    return original;
  }

}
