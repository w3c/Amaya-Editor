// cacheStatistics.java
// $Id: cacheStatistics.java,v 1.5 1998/02/19 12:52:51 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.www.protocol.http.cache;

public class cacheStatistics {
    cacheStatistics() {
    }

}
