// TeeMonitor.java
// $Id: TeeMonitor.java,v 1.3 1998/02/19 12:52:41 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html


package org.w3c.www.protocol.http.cache;

import java.io.*;

// FIXME doc

public interface TeeMonitor {
    public void notifyTeeFailure();
    public void notifyTeeSuccess(int size);
}

