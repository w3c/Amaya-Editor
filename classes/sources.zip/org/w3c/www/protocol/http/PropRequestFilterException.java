// PropRequestFilterException.java
// $Id: PropRequestFilterException.java,v 1.3 1998/01/22 14:35:50 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.www.protocol.http;

public class PropRequestFilterException extends Exception {

    public PropRequestFilterException(String msg) {
	super(msg);
    }

}
