// NotAProtocolException.java
// $Id: NotAProtocolException.java,v 1.1 1998/01/26 13:31:59 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.tools.resources ;

public class NotAProtocolException extends Exception {

  public NotAProtocolException (String msg) {
    super(msg);
  }

}
