// UnknownResourceException.java
// $Id: UnknownResourceException.java,v 1.1 1998/01/22 13:02:24 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.tools.resources.store ;

import org.w3c.tools.resources.*;

public class UnknownResourceException extends RuntimeException {

    public UnknownResourceException (Resource resource) {
	super("ResourceStore mismatch for resource "+resource.getIdentifier());
    }

}
