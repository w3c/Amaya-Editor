// DateField.java
// $Id: DateField.java,v 1.2 1998/01/22 13:07:20 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.tools.forms ;

import java.awt.*;
import java.util.Date ;

class DateFieldEditor extends Panel {
	
}

public class DateField {
}
