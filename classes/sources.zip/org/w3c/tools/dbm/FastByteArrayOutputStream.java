// FastByteArrayOutputStream.java
// $Id: FastByteArrayOutputStream.java,v 1.2 1998/01/22 13:06:35 bmahe Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.tools.dbm ;

import java.io.* ;

class FastByteArrayOutputStream extends ByteArrayOutputStream {
    FastByteArrayOutputStream(byte buf[]) {
	this.buf = buf ;
    }
}
