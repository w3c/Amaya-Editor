// UnixException.java
// $Id: UnixException.java,v 1.4 1998/01/22 14:25:53 bmahe Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.util;

public class UnixException extends Exception {

    UnixException(String msg) {
	super(msg);
    }

}
