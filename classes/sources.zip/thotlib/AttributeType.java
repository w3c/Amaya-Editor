package thotlib;

/*
 * Java Classe associated to an Attribute type of an Attribute
 */

public class AttributeType {
    long attributeType;

    public AttributeType() {
        attributeType = 0;
    }
    public AttributeType(long value) {
        attributeType = value;
    }
    public AttributeType(Attribute el) {
    }
    public AttributeType(String TypeName) {
    }

    public String Name() {
        return(null);
    }
}


