package thotlib;

/*
 * Java Classe associated to an Attribute type of an Attribute
 */

public class AttributeType {
    long sschema = 0;
    int  type = 0;

    public AttributeType() {
    }
    public AttributeType(int t) {
        type = t;
    }
    public AttributeType(long s, int t) {
        sschema = s;
        type = t;
    }
    public AttributeType(Attribute el) {
    }
    public AttributeType(String TypeName) {
    }

    public String Name() {
        return(null);
    }
}


