package thotlib;

/*
 * Java Classe associated to an Attribute type of an Attribute
 */

public class AttributeType {
    long sschema = 0;
    int  type = 0;

    public AttributeType() {
    }
    public AttributeType(int t) {
// System.out.println("AttributeType(" + t + ")");
        type = t;
    }
    public AttributeType(long s, int t) {
// System.out.println("AttributeType(" + s + ", " + t + ")");
        sschema = s;
        type = t;
    }
    public AttributeType(Attribute el) {
    }
    public AttributeType(String TypeName) {
    }

    public String Name() {
        return(null);
    }

    /*
     * Indirect access methods from C
     */
    protected long get_sschema(long value) { return(sschema); }
    protected void set_sschema(long value) { sschema = value; }
    protected int get_sschema(int value) { return((int) sschema); }
    protected void set_sschema(int value) { sschema = value; }
    protected int get_type() { return(type); }
    protected void set_type(int value) { type = value; }
}


