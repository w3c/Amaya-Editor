package thotlib;

/*
 * Stub classes to interface the Thotlib Language accesses from Java
 */


public class Language {
    char lang;

    /*
     * Indirect access methods from C
     */
    protected int get_lang() { return((int) lang); }
    protected void set_lang(int value) { lang = (char) value; }
}

