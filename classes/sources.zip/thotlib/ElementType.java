package thotlib;
import java.io.*;

/*
 * Java Classe associated to an ElementType of an Element.
 */

public class ElementType {
    long sschema = 0;
    int type = 0;

    public ElementType() {
    }
    public ElementType(int t) {
        type = t;
    }
    public ElementType(long s, int t) {
	sschema = s;
        type = t;
    }
    public ElementType(Element el) {
        Extra.TtaGetElementType(this, el.element);
    }
    public ElementType(String TypeName) {
        APITree.TtaGiveTypeFromName(this, TypeName);
    }
    public ElementType(Document doc, int value) {
	sschema = doc.SSchema();
        type = value;
    }

    public String Name() {
        return(Extra.TtaGetElementTypeName(sschema, type));
    }
    public int Value() {
        return(type);
    }
    public void SetType(int value) {
	type = value;
    }
    public void SetSSchema(long value) {
	sschema = value;
    }
    public int GetType() {
	return(type);
    }
}


