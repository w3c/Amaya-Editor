package thotlib;
import java.io.*;

/*
 * Java Classe associated to an ElementType of an Element.
 */

public class ElementType {
    long sschema = 0;
    int type = 0;

    public ElementType() {
    }
    public ElementType(int t) {
        type = t;
    }
    public ElementType(long s, int t) {
	sschema = s;
        type = t;
    }
    public ElementType(Element el) {
        Extra.TtaGetElementType(this, el.element);
    }
    public ElementType(String TypeName) {
        APITree.TtaGiveTypeFromName(this, TypeName);
    }
    public ElementType(Document doc, int value) {
	sschema = doc.SSchema();
        type = value;
    }
    public ElementType(int doc, int value) {
	sschema = APIDocument.TtaGetDocumentSSchema(doc);
        type = value;
    }

    public String Name() {
        return(Extra.TtaGetElementTypeName(sschema, type));
    }
    public int Value() {
        return(type);
    }
    public void SetType(int value) {
	type = value;
    }
    public void SetSSchema(long value) {
	sschema = value;
    }
    public int GetType() {
	return(type);
    }

    public void Print() {
        System.out.println("ElementType " + this + " sschema : " + sschema + " type : " + type);
    }

    /*
     * Indirect access methods from C
     */
    protected long get_sschema(long value) { return(sschema); }
    protected void set_sschema(long value) { sschema = value; }
    protected int get_sschema(int value) { return((int) sschema); }
    protected void set_sschema(int value) { sschema = value; }
    protected int get_type() { return(type); }
    protected void set_type(int value) { type = value; }
}


