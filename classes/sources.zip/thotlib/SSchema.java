package thotlib;

/*
 * Java Classe associated to a Structure Schema of a Thotlib document.
 */

public class SSchema {
    long sschema;

    public SSchema(int document) {
        sschema = APIDocument.TtaGetDocumentSSchema(document);
    }
    public SSchema(long ss) {
        sschema = ss;
    }
}


