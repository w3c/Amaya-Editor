package thotlib;

/*
 * Java Classe associated to a Structure Schema of a Thotlib document.
 */

public class SSchema {
    int sschema;
}


