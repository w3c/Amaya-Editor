package thotlib;

/*
 * Stub classes to interface the Thotlib document accesses from Java
 */


public class Document {
    public int document;

    public static final int DisplayImmediately = APIView.DisplayImmediately;
    public static final int DeferredDisplay = APIView.DeferredDisplay;
    public static final int NoComputedDisplay = APIView.NoComputedDisplay;

    public Document() {
        document = 0;
    }

    public Document(int doc) {
        document = doc;
    }

    public Element Root() {
        Element current = new Element(APITree.TtaGetMainRoot(document));
	return current;
    }
    public long SSchema() {
        long current = APIDocument.TtaGetDocumentSSchema(document);

	return current;
    }
    public void SetModified(boolean modified) {
	if (modified)
	    APIDocument.TtaSetDocumentModified(document);
	else
	    APIDocument.TtaSetDocumentUnmodified(document);
    }
    public boolean IsModified() {
        int res = APIDocument.TtaIsDocumentModified(document);

	if (res != 0) return(true);
	return(false);
    }
    public void SetDisplayMode(int mode) {
        APIView.TtaSetDisplayMode(document, mode);
    }
    public int DocNo() {
        return(document);
    }

    /*
     * Indirect access methods from C
     */
    protected int get_document() { return(document); }
    protected void set_document(int value) { document = value; }
}

