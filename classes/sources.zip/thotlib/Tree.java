package thotlib;

/*
 * Java Classe associated to Tree manipulation
 */

public class Tree {
}

