package thotlib;

/*
 * Java Classe associated to Elements in a Thotlib document
 */

public class Element {
    public long element;

    /*
     * These functions just create wrapper classes around existing
     * Thot Elements.
     */
    public Element() {
        element = 0;
    }
    public Element(long value) {
        element = value;
    }

    /*
     * These functions create new Elemnents in the Thot library and attach
     * them to the Element class.
     */
    public Element(int docNo, int type) {
	ElementType elType = new ElementType(docNo, type);
        element = Extra.TtaNewElement(docNo, elType);
    }
    public Element(Document doc, int type) {
	ElementType elType = new ElementType(doc, type);
        element = Extra.TtaNewElement(doc.document, elType);
    }
    public Element(Document doc, ElementType elType) {
        element = Extra.TtaNewElement(doc.document, elType);
    }

    public static Element NewTree(Document doc, ElementType elType, String label) {
        Element el = new Element();
        el.element = Extra.TtaNewTree(doc.document, elType, label);
	return el;
    }
    public static Element NewTree(Document doc, int type, String label) {
        Element el = new Element();
	ElementType elType = new ElementType(doc, type);
        el.element = Extra.TtaNewTree(doc.document, elType, label);
	return el;
    }
    public static Element NewTree(Document doc, ElementType elType) {
        Element el = new Element();
        el.element = Extra.TtaNewTree(doc.document, elType, null);
	return el;
    }
    public static Element NewTree(Document doc, int type) {
        Element el = new Element();
	ElementType elType = new ElementType(doc, type);
        el.element = Extra.TtaNewTree(doc.document, elType, null);
	return el;
    }

    public Element CreateDescent(ElementType elType) {
        Element el = new Element();
        el.element = Extra.TtaCreateDescent(this.DocNo(), this.element, elType);
	return el;
    }
    public Element CreateDescent(int type) {
	Document doc = this.Document();
        Element el = new Element();
	ElementType elType = new ElementType(doc, type);
        el.element = Extra.TtaCreateDescent( this.DocNo(), this.element, elType);
	return el;
    }
    public Element CreateDescentWithContent(ElementType elType) {
        Element el = new Element();
        el.element = Extra.TtaCreateDescentWithContent(
	                 this.DocNo(), this.element, elType);
	return el;
    }
    public Element CreateDescentWithContent(int type) {
	Document doc = this.Document();
        Element el = new Element();
	ElementType elType = new ElementType(doc, type);
        el.element = Extra.TtaCreateDescentWithContent(
	                 this.DocNo(), this.element, elType);
	return el;
    }

    public Element CopyTree(Document dest, Element parent) {
        Element el = new Element();
        el.element = APITree.TtaCopyTree(this.element,
	                 this.DocNo(), dest.document, parent.element);
	return el;
    }

    /*
     * These functions destroy Elements in the Thot library
     */
    public void RemoveTree() {
        APITree.TtaRemoveTree(this.element, this.DocNo());
    }

    /*
     * These functions destroy Elements in the Thot library
     */
    public void DeleteTree() {
        APITree.TtaDeleteTree(this.element, this.DocNo());
	this.element = 0;
    }

    /*
     * accesses to the Element value.
     */
    public long Value() {
        return element;
    }

    public Document Document() {
        Document doc = new Document(APITree.TtaGetDocument(this.element));
	return doc;
    }
    public int TypeNo() {
	ElementType elType = new ElementType(this);
	return(elType.GetType());
    }
    public ElementType Type() {
	ElementType elType = new ElementType(this);
	return(elType);
    }
    public int DocNo() {
        return (APITree.TtaGetDocument(this.element));
    }
    public Attribute GetAttribute(AttributeType atType) {
        Attribute at = new Attribute();
	at.attribute = Extra.TtaGetAttribute(this.element, atType);
        return(at);
    }

    /*
     * Functions to access the content of an element.
     */
    public char Language() {
	int value = 0;

        AttributeType atType = new AttributeType(0, 1);
        long attribute = Extra.TtaGetAttribute(this.element, atType);
	if (attribute != 0) {
	    value = APIAttribute.TtaGetAttributeValue(attribute);
	}
	if (value == 0) {
	    return(APILanguage.TtaGetDefaultLanguage());
	}

	return ((char) value);
    }

    public StringBuffer TextContent() {
	int type = this.Type().GetType();
	StringBuffer text = null;

        /*
	 * This is an hard-coded value, all text element in Thot
	 * have an internal type 1 whatever the DTD.
	 */
	if (type != 1) {
	    /*
	     * Do a recursive call with concatenation on all children
	     */
	    Element child = this.FirstChild();
	    while (child != null) {

	        StringBuffer subtext = child.TextContent();
	        if (subtext != null) {
		    if (text == null) text = subtext;
		    else text.append(subtext);
		}
		child = child.NextSibling();
	    }
	} else {
	    /* Get the lenght of the text and allocate a buffer to store it */
	    int len = APIContent.TtaGetTextLength (this.element);
	    if (len < 30) len = 30;
	    len += 1;
	    text = new StringBuffer(len * 2 + 10);

	    /* create the temporary objects needed to get the retun values */
	    IntPtr length = new IntPtr(len);
	    Language lang = new Language();

	    /* get the string in the buffer */
	    APIContent.TtaGiveTextContent(this.element, text, length, lang);

            if (text.length() != length.value()) {
	        System.out.println("TtaGiveTextContent : length : " +
		    length.value() + ", text is " + text.length() + " chars");
	    }
	    /* truncate it to the correct size
            text.setLength(length.value()); */
	}
        return (text);
    }

    public void SetTextContent(String content) {
        APIContent.TtaSetTextContent(this.element, content, this.Language(),
	                             this.DocNo());
    }

    /*
     * extra navigation methods.
     */
    public Element Parent() {
        long parent = APITree.TtaGetParent(this.element);
        if (parent == 0) return null;
	Element el = new Element();
        el.element = parent;
	return(el);
    }
    public Element FirstChild() {
        long child = APITree.TtaGetFirstChild(this.element);
        if (child == 0) return null;
	Element el = new Element();
        el.element = child;
	return(el);
    }
    public Element LastChild() {
        long child = APITree.TtaGetLastChild(this.element);
        if (child == 0) return null;
	Element el = new Element();
        el.element = child;
	return(el);
    }
    public Element PreviousSibling() {
	Element el = new Element(this.element);
        APITree.TtaPreviousSibling(el);
        if (el.element == 0) return(null);
	return(el);
    }
    public Element NextSibling() {
	Element el = new Element(this.element);
        APITree.TtaNextSibling(el);
        if (el.element == 0) return(null);
	return(el);
    }
    public Element Successor() {
        long successor = APITree.TtaGetSuccessor(this.element);
        if (successor == 0) return null;
	Element el = new Element();
        el.element = successor;
	return(el);
    }
    public Element Predecessor() {
        long predecessor = APITree.TtaGetPredecessor(this.element);
        if (predecessor == 0) return null;
	Element el = new Element();
        el.element = predecessor;
	return(el);
    }

    /*
     * Manipulation on tree.
     */
    public void InsertSibling(Element el, boolean before) {
        APITree.TtaInsertSibling(el.element, this.element, before, this.DocNo());
    }
    public void InsertChild(Element el, boolean first) {
        if (first)
	    APITree.TtaInsertFirstChild(el, this.element, this.DocNo());
	else {
	    Element last = this.LastChild();

	    if (last != null)
		APITree.TtaInsertSibling(el.element, last.element, false,
					 this.DocNo());
            else
		APITree.TtaInsertFirstChild(el, this.element, this.DocNo());
	}
    }

    /*
     * Select : set up the Thot selection to be this element.
     */
    public void Select() {
        APISelection.TtaSelectElement(this.DocNo(), this.element);
    }

    /*
     * AskUserClick : ask the user to click on one element in one
     *    of the open documents and returns the element selected.
     */
    public static Element AskUserClick() {
        Element el = new Element();
        Document doc = new Document();

	APIInterface.TtaClickElement(doc, el);
	
	if ((el.element == 0) || (doc.document == 0)) return(null);
	return(el);
    }

    /*
     * Print : debug.
     */
    public void Print() {
        System.out.println("Element : " + this + " , element = " + element);
	Debug();
    }
    public native void Debug();

    /*
     * Indirect access methods from C
     */
    protected long get_element(long value) { return(element); }
    protected void set_element(long value) { element = value; }
    protected int get_element(int value) { return((int) element); }
    protected void set_element(int value) { element = value; }

}


