package thotlib;

/*
 * Java Classe associated to an PRule.
 */

public class PRule {
    int prule;

    public PRule() {
        prule = 0;
    }
    public PRule(int value) {
        prule = value;
    }
}


