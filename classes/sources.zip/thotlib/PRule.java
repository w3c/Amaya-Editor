package thotlib;

/*
 * Java Classe associated to an PRule.
 */

public class PRule {
    long prule;

    public PRule() {
        prule = 0;
    }
    public PRule(int value) {
        prule = value;
    }

    /*
     * Indirect access methods from C
     */
    protected long get_prule(long value) { return(prule); }
    protected void set_prule(long value) { prule = value; }
    protected int get_prule(int value) { return((int) prule); }
    protected void set_prule(int value) { prule = value; }

}


