package thotlib;

/*
 * Java Classe for all native functions not generated automatically
 * by javastub.
 */

public class Extra {
    public static native void TtaRemoveSchemaExtension(int document, int extension);
    public static native void Java2CCallback(Object arg, long callback);
    public static native void JavaPollLoop();
    public static native void JavaStopPoll();
    public static native void JavaXFlush();
}


