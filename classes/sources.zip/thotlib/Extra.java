package thotlib;

/*
 * Java Classe for all native functions not generated automatically
 * by javastub.
 */

public class Extra {
    public static native void Java2CCallback(Object arg, long callback);
    public static native void JavaPollLoop();
    public static native void JavaStopPoll();
    public static native void JavaXFlush();
    public static native int JavaStartApplet(String classname,
					     String signature,
                                             int doc,
                                             String[] argv)
                             throws ClassNotFoundException, NoSuchMethodError;
    /*
     * JavaRegisterAction : Register an Action handler
     */
    public static native void JavaRegisterAction(Action handler,
                                                 String ActionName);
    /*
     * JavaRegisterMenuAction : Register an Menu Action callback
     */
    public static native void JavaRegisterMenuAction(Action handler,
                                                 String ActionName);
    /*
     * JavaUnregisterAction : Unregister an Action handler
     */
    public static native void JavaUnregisterAction(String ActionName);
    /*
     * JavaUnregisterMenuAction : Unregister an Menu Action callback
     */
    public static native void JavaUnregisterMenuAction(String ActionName);
    /*
     * AddEditorActionEvent : Add an action at the Application level,
     *     (equivalent to EDITOR.A actions).
     *   An action with the corresponding ActionName MUST have
     *   been registered before (see Action and SampleAction classes).
     */
    static public native void AddEditorActionEvent(String ActionName,
                               int eventType, int typeId, boolean pre);

    /*
     * AddSSchemaActionEvent : Add an action at the SSchema level,
     *     (equivalent to HTML.A actions).
     *   An action with the corresponding ActionName MUST have
     *   been registered before (see Action and SampleAction classes).
     */
    static public native void AddSSchemaActionEvent(String DTDName,
                               String ActionName, int eventType,
                               int typeId, boolean pre);

    /*
     * ElementType and AttributeType access functions : i
     *     the original functions use a struct composed
     *     of a pointer + an integer, we need to provide
     *     different interfaces for Java.
     */
    static public native void TtaGetElementType(ElementType elType, long el);
    static public native String TtaGetElementTypeName(long sschema, int type);
    static public native long TtaNewAttribute(AttributeType atType);
    static public native long TtaGetAttribute(long element, AttributeType atType);
    static public native void TtaSearchAttribute(AttributeType atType, int scope, long element, Element el, Attribute at);
    static public native long TtaNewElement(int document, ElementType elType);
    static public native long TtaNewTree(int document, ElementType elType, String label);
    static public native long TtaSearchTypedElement(ElementType elType, int scope, Element el);
    static public native long TtaCreateDescent(int document, long element, ElementType elType);
    static public native long TtaCreateDescentWithContent(int document, long element, ElementType elType);
}


